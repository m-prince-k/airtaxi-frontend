import './App.css';
import RouterLink from './route/routes';
//import 'bootstrap/dist/css/bootstrap.min.css';
import './util/css/custom.scss'
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
function App(props) {
  return (
   <>
   <RouterLink {...props}/>
   </>
  );
}

export default App;
