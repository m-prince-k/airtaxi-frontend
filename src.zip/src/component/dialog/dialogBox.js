import { useEffect } from "react";

export default function DialogBox (ref,handle) {
    useEffect(() => {
        const listener = event => {
            const e1=ref?.current;
            if(!e1 || e1.contains(event.target)) {
                return ;
            }
            handle(event)
        };
        document.addEventListener("mousedown",listener);
        document.addEventListener("touchstart",listener);
        return () => {
            document.removeEventListener("mousedown",listener)
        }
    },[ref,handle])
}