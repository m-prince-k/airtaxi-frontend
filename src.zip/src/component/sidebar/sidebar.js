import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { logout } from "../store/login/authSlice";
import logo from "../../util/img/icons/headerlogo.png"
import dashboard from "../../util/img/icons/dashboard.svg"
import employee from "../../util/img/icons/employee.svg"
import user from "../../util/img/icons/user.svg"
import flight from "../../util/img/icons/flight.svg"
import flightseat from "../../util/img/icons/flightseat.svg"
import Airport from "../../util/img/icons/airport.svg"
import logouticon from "../../util/img/icons/logout.svg"
import padLock from "../../util/img/icons/padlock1.png"

export default function SideBar() {


		const [isOpen, setIsopen] = useState(false);
	
		const ToggleSidebar = () => {
			isOpen === true ? setIsopen(false) : setIsopen(true);
		}
	const dispatch=useDispatch();
	const navigate=useNavigate();
	const [activeSideBar,setActiveSideBar]=useState("");
	
	const handleLogout = (e) => {
		e.preventDefault();
		dispatch(logout())
		localStorage.removeItem("authLogger");
		navigate("/")

		caches.keys().then((names) => {
			// Delete all the cache files
			names.forEach(name => {
				caches.delete(name);
			})
		});
	}
	
	const handleActive=(e)=>{
		e.preventDefault();
		//setActiveSideBar(value)
	}
    return (
        <>

<Link className="sidebar-toggle js-sidebar-toggle position-absolute airtaxi-sidebar-custom" onClick={ToggleSidebar}>
          <i className="hamburger align-self-center"></i>
        </Link>
        <nav id="sidebar" className={`sidebar js-sidebar ${isOpen == true ? 'collapsed' : ''}`}>
			<div className="sidebar-content js-simplebar">
				<Link className="sidebar-brand" to="/">
          <span className="align-middle"><img src={ logo} /></span>
        </Link>


				<ul className="sidebar-nav">
					{/* <li className="sidebar-header">
						Pages
					</li> */}
 
					{/* <li className="sidebar-item active"> */}
					<li className='sidebar-item'>
						<NavLink className={(navData) => (navData.isActive ? 'custom-active':'sidebar-link')}to="/">
						<img src={ dashboard} /> <span className="align-middle">Dashboard</span>
            </NavLink>
					</li>

					<li className='sidebar-item'>
						<NavLink className={'sidebar-link'}  to="/employee">
						<img src={ employee} /><span className="align-middle">Employee</span>
            </NavLink>
					</li>
					<li className={'sidebar-item' + (activeSideBar=='User' ? ' active':'')} onClick={(e) => handleActive("User")}>
						<Link className="sidebar-link" to="/user">
						<img src={ user} /><span className="align-middle">User</span>
            </Link>
					</li>

					<li className="sidebar-item">
						<Link className="sidebar-link" to="/flightListing">
						<img src={ flight} /> <span className="align-middle">Flights</span>
            </Link>
					</li>

					<li className="sidebar-item">
						<Link className="sidebar-link" to="/aircraftListing">
						<img src={ flightseat} /> <span className="align-middle">Aircraft</span>
            </Link>
					</li>

					<li className="sidebar-item">
						<Link className="sidebar-link" to="/airport">
						<img src={ Airport} /> <span className="align-middle">Airports</span>
            </Link>
					</li>


					{/* <li className="sidebar-item">
						<Link className="sidebar-link" to="/changePassword">
						<img src={ padLock} height={22} width={22} /> <span className="align-middle">Change Password</span>
            </Link>
					</li> */}

					{/* <li className="sidebar-item" onClick={(e) => handleLogout(e)}>
						<Link className="sidebar-link" to="#"><img src={ logouticon} />
              			<span className="align-middle">Logout</span>
            </Link>
					</li> */}
				</ul>
			</div>
		</nav>
        </>
    )
}