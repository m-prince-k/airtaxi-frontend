import React from 'react'
import GoogleLogin from 'react-google-login'
import { useNavigate } from 'react-router-dom'

export default function GoogleLoginComponent() {
    const navigate = useNavigate();
    const handleSocial = async (response) => {
        const userPayload  ={
           socialType:"google",
           email:response?.profileObj?.email,
           tokenId:response?.tokenId 
        }
        //now dispatch the social payload
        //await dispatch(socialAsync(userPayload))
    navigate("/signup")
    }
  return (
    <>
  <GoogleLogin
      // clientId="658977310896-knrl3gka66fldh83dao2rhgbblmd4un9.apps.googleusercontent.com"
      clientId="63826579796-hph6uo9sfgsdd0m1k8c23km88gkfp490.apps.googleusercontent.com"
      buttonText="Login"
      onSuccess={handleSocial}
      onFailure={handleSocial}
      cookiePolicy={'single_host_origin'}
      disabled={false}
      isSignedIn={false}
    />
    </>
  )
}
