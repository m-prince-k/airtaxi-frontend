import axios from "axios";
import { toast } from "react-toastify";
import { developmentBaseUrl, createAircraft, blockUnBlockAirCraft, autoPopulateAircraft, viewAirCraft,deleteAircraft,updateAircraft, getAllAirCraft } from "../../../util/constant";

//generate aircraft 
const createAirCraft = async(userData,tokenDetail) => {
    try { 
        const response = await axios.post(developmentBaseUrl + createAircraft,userData,tokenDetail);
        if(response?.data?.data?.message){
            toast.success(response?.data?.data?.message)
        }
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}

const getAirCraftListing = async(tokenDetail) => {
    try { 
        const response = await axios.get(developmentBaseUrl + getAllAirCraft,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}

const blockUnBlockAircraft = async(userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+blockUnBlockAirCraft,userData,tokenDetail);
        if(response?.data?.message) {
            toast.success(response?.data?.message)
        }
        return response?.data?.data;
    } catch (error) {
        throw(error)
    }
}

const autoFilledAircraft = async (userData,tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl + autoPopulateAircraft+"/"+userData,tokenDetail);
        return response?.data?.data
    } catch (error) {
        console.log('_____________________________________error',error);
        throw(error)
    }
}

const updateAirCraft = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl + updateAircraft,userData,tokenDetail)
        if(response.data.message) {
            toast.success(response.data.message)
        }
        return response?.data?.data;
    } catch (error) {
       if(error.response.data.message) {
            toast.error(error.response.data.message)
        }
        throw(error)
    }
}

const deleteaircraftTaxi = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+deleteAircraft,userData,tokenDetail);
        if(response.data.message){
            toast.success(response.data.message)
        }
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const viewAircraft = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+viewAirCraft,userData,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}


const CreateAircraftService = {
    createAirCraft,
    getAirCraftListing,
    blockUnBlockAircraft,
    autoFilledAircraft,
    updateAirCraft,
    deleteaircraftTaxi,
    viewAircraft
}
export default CreateAircraftService;