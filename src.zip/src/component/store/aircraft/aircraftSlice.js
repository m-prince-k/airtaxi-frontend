import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import CreateAircraftService from "./aircraftService";


const initialState = {
    isError: false,
    isSuccess: false,
    isLoading: false,
    message: "",
    createAirCraftDetail:"",
    creationAircraft:"",
    getAirCraftDetail:"",
    blockunblockAirCraftDetail:"",
    autoPopulateAirCraftDetail:"",
    updateAircraftDetail:"",
    updateMessage:"",
    deleteAirCraftDetail:"",
    viewAircraftDetail:"",
    isSuccess1:false,
    isAirCreator:false,
    isUpdateCraator:false
}

export const createAirCraft = createAsyncThunk('get/createAirCraft',async (userData,thunkApi)=>{
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await CreateAircraftService.createAirCraft(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});


export const getAllAirCraftDetail = createAsyncThunk('get/getAirCraft',async (_,thunkApi)=>{
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await CreateAircraftService.getAirCraftListing(tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const blockUnblockairCraft = createAsyncThunk('block/aircraft',async (userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await CreateAircraftService.blockUnBlockAircraft(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const autoPopulateAircraft = createAsyncThunk('get/aircraft',async (userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await CreateAircraftService.autoFilledAircraft(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const editAirCraft = createAsyncThunk('update/aircraft',async (userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await CreateAircraftService.updateAirCraft(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});


export const deleteAircraft = createAsyncThunk('update/delete',async (userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await CreateAircraftService.deleteaircraftTaxi(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const viewAircraftTaxi = createAsyncThunk('get/viewaircraft',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await CreateAircraftService.viewAircraft(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})




export const aircraftReducer = createSlice({
    name:'admin-flight',
    initialState,
    reducers:{
        logout:(state)=>{
            state.isError=false;
            state.isLoading=false;
            state.isSuccess=false;
            state.message="";
           state.createAirCraftDetail="";
           state.blockunblockAirCraftDetail="";
           state.autoPopulateAirCraftDetail="";
           state.deleteAirCraftDetail=""
           state.viewAircraftDetail="";
           state.updateMessage="";
           state.isAirCreator="";
           state.isUpdateCraator=""
        }
    },
    extraReducers:(builder) => {
        builder.addCase(createAirCraft.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(createAirCraft.fulfilled,(state,action) => {
            state.isLoading=false
            state.isAirCreator=true
            state.createAirCraftDetail=action.payload
            state.message="Aircraft created successfully"
        }).addCase(createAirCraft.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isAirCreator=false
        }).addCase(getAllAirCraftDetail.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(getAllAirCraftDetail.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.getAirCraftDetail=action.payload
        }).addCase(getAllAirCraftDetail.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(blockUnblockairCraft.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(blockUnblockairCraft.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.blockunblockAirCraftDetail=action.payload
        }).addCase(blockUnblockairCraft.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(autoPopulateAircraft.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(autoPopulateAircraft.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.autoPopulateAirCraftDetail=action.payload
        }).addCase(autoPopulateAircraft.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(editAirCraft.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
            state.isUpdateCraator=false
            state.message=""
        }).addCase(editAirCraft.fulfilled,(state,action) => {
            state.isLoading=false
            state.isUpdateCraator=true
            state.updateAircraftDetail=action.payload
            state.message="Aircraft has been update successfully"
        }).addCase(editAirCraft.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isUpdateCraator=false
        }).addCase(deleteAircraft.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(deleteAircraft.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.deleteAirCraftDetail=action.payload
        }).addCase(deleteAircraft.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(viewAircraftTaxi.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(viewAircraftTaxi.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.viewAircraftDetail=action.payload
        }).addCase(viewAircraftTaxi.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        })
    }
});

export const { reset } = aircraftReducer.actions;
export default aircraftReducer.reducer