import axios from "axios";
import { developmentBaseUrl, Count } from "../../../util/constant";
const dashboardCount = async(tokenDetail) => {
    try { 
        const response = await axios.get(developmentBaseUrl + Count,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const dashboardService = {
    dashboardCount,
}
export default dashboardService;