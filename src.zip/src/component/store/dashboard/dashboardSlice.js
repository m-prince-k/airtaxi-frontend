import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";
import dashboardService from "./dashbaordService";

const initialState = {
    isError: false,
    isSuccess: false,
    isLoading: false,
    message: "",
    dashboardResult:""
}
export const getDashboardResult = createAsyncThunk('get/dashboard',async (_,thunkApi)=>{
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await dashboardService.dashboardCount(tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});
export const dashboardReducer = createSlice({
    name:'admin-dashboard',
    initialState,
    reducers:{
        logout:(state)=>{
            state.isError=false;
            state.isLoading=false;
            state.isSuccess=false;
            state.message="";
            state.dashboardResult=""
        }
    },
    extraReducers:(builder) => {
        builder.addCase(getDashboardResult.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(getDashboardResult.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.dashboardResult=action.payload
        }).addCase(getDashboardResult.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        })
    }
});

export const { reset } = dashboardReducer.actions;
export default dashboardReducer.reducer
