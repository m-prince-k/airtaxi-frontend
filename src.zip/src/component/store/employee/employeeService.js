import axios from "axios";
import { toast } from "react-toastify";
import { developmentBaseUrl, getEmployeeListing ,getFilledEmployee, editUserByAdmin, deleteEmp,viewEmployeeProfile,blockUnblockEmployee,addemployee } from "../../../util/constant";
const employeeListing = async(tokenDetail) => {
    try { 
        const response = await axios.get(developmentBaseUrl + getEmployeeListing,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const deleteEmployee = async (userData,tokenDetail) => {
    try {
        const response = await axios.delete(developmentBaseUrl + deleteEmp+"/"+userData,tokenDetail);
        if(response.data.message){
            toast.success(response.data.message)
        }
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const autoFilledEmployee = async (userData,tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl + getFilledEmployee+"/"+userData,tokenDetail);
        return response?.data?.data
    } catch (error) {
        console.log('_____________________________________error',error);
        throw(error)
    }
}
const updateEmployee= async (userData,userId,tokenDetail) => {
    try {
        const form=new FormData();
        form.append("first_name",userData.first_name);
        form.append("last_name",userData.last_name);
        form.append("email",userData.email);
        form.append("phone_number",userData.phone_number);
        form.append("country_code",userData.country_code);
        form.append("location",userData.location);
        form.append("profile_pic",userData.profile_pic)
        form.append("id",userId)

        const response = await axios.post(developmentBaseUrl + editUserByAdmin,form,tokenDetail);
        if(response?.data?.message) {
            toast.success(response?.data?.message)
        }
        return response?.data?.data && response?.data
    } catch (error) {
        console.log('_____________________________________error',error);
        throw(error)
    }
}

const viewEmployee= async (userData,tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl + viewEmployeeProfile+"/"+userData,tokenDetail);
        return response?.data?.data
    } catch (error) {
        console.log('_____________________________________error',error);
        throw(error)
    }
}
const blockUnblockUserEmplyee = async(userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+blockUnblockEmployee,userData,tokenDetail);
        console.log('===================================response is here',response)
        if(response?.data?.message) {
            toast.success(response?.data?.message)
        }
        return response?.data?.data;

    } catch (error) {
        throw(error)
    }
}

const addEmployeeByAdmin=async(userData,tokenDetail) => {
    try {
        let form = new FormData();
        form.append("first_name",userData.first_name)
        form.append("last_name",userData.last_name)
        form.append("email",userData.email)
        form.append("location",userData.location)
        form.append("user_role",userData.user_role)
        form.append("country_code",userData.country_code)
        form.append("phone_number",userData.phone_number)

        const response=await axios.post(developmentBaseUrl+addemployee,form,tokenDetail);
        console.log('______________________________form is here',response)
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const getAllEmployeeListing = {
    employeeListing,
    autoFilledEmployee,
    updateEmployee,
    deleteEmployee,
    viewEmployee,
    blockUnblockUserEmplyee,
    addEmployeeByAdmin
}
export default getAllEmployeeListing;