import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";
import getAllEmployeeListing from "./employeeService";
const initialState = {
    isError: false,
    isSuccess: false,
    isLoading: false,
    message: "",
    EmployeeDetails: "",
    autoFilledEmployee:"",
    updateEmployeeDetail:"",
    deleteEmpDetail:"",
    viewEmployeeDetail:"",
    blockUnblockDetail:"",
    addEmployeeDetail:""
}

export const viewEmpDetail = createAsyncThunk('get/view',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllEmployeeListing.viewEmployee(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})
export const getAutoFilledEmployee = createAsyncThunk('get/autofilled',async (userData,thunkApi)=>{
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllEmployeeListing.autoFilledEmployee(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const employeeDeleted = createAsyncThunk('get/deleteEmp',async (userData,thunkApi)=>{
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllEmployeeListing.deleteEmployee(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const editEmployee=createAsyncThunk ('update/employee',async (userData,thunkApi) => {
    try {
        const userId=userData.id
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{
            "Content-Type":"multipart/form-data",
            Authorization:`Bearer ${token}`}
        }
        return await getAllEmployeeListing.updateEmployee(userData,userId,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});
export const addEmployee =createAsyncThunk('post/createEmployee',async (userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"));
        const tokenDetails={headers:{
           'Content-Type': 'multipart/form-data',
            Authorization:`Bearer ${token}`,
            },
        }
        return await getAllEmployeeListing.addEmployeeByAdmin(userData,tokenDetails)
    } catch (error) {
        const createMessage=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(createMessage)
    }

});
export const getAllEmployeeBySuperAdmin = createAsyncThunk('get/employeeListing',async (_,thunkApi)=>{
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllEmployeeListing.employeeListing(tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data && error.response.message) || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const blockUnblockEmployee = createAsyncThunk('get/blockunblockuser',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllEmployeeListing.blockUnblockUserEmplyee(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})

export const employeeReducer = createSlice({
    name:'admin-employee',
    initialState,
    reducers:{
        logout:(state)=>{
            state.isError=false;
            state.isLoading=false;
            state.isSuccess=false;
            state.message="";
            state.EmployeeDetails="";
            state.autoFilledEmployee="";
            state.updateEmployeeDetail="";
            state.deleteEmpDetail="";
            state.blockUnblockDetail="";
            state.addEmployeeDetail="";
        }
    },
    extraReducers:(builder) => {
        builder.addCase(getAllEmployeeBySuperAdmin.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(getAllEmployeeBySuperAdmin.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.EmployeeDetails=action.payload
        }).addCase(getAllEmployeeBySuperAdmin.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(getAutoFilledEmployee.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(getAutoFilledEmployee.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.autoFilledEmployee=action.payload
        }).addCase(getAutoFilledEmployee.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(editEmployee.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(editEmployee.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.updateEmployeeDetail=action.payload
        }).addCase(editEmployee.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(employeeDeleted.pending,(state)=>{
            state.isLoading=true
            state.isSuccess=false
        }).addCase(employeeDeleted.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.deleteEmpDetail=action.payload
        }).addCase(employeeDeleted.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(viewEmpDetail.pending,(state)=>{
            state.isLoading=true
            state.isSuccess=false
        }).addCase(viewEmpDetail.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.viewEmployeeDetail=action.payload
        }).addCase(viewEmpDetail.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(blockUnblockEmployee.pending,(state)=>{
            state.isLoading=true
            state.isSuccess=false
        }).addCase(blockUnblockEmployee.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.blockUnblockDetail=action.payload
        }).addCase(blockUnblockEmployee.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(addEmployee.pending,(state)=>{
            state.isLoading=true
            state.isSuccess=false
        }).addCase(addEmployee.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.addEmployeeDetail=action.payload
        }).addCase(addEmployee.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        })
    }
});

export const { reset } = employeeReducer.actions;
export default employeeReducer.reducer
