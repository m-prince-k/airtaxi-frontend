import axios from "axios";
import { toast } from "react-toastify";
import {developmentBaseUrl,getFlight,scheduleFlightByParentId, getSingleForBookedSeat,getAllAirport,getAllAirCraft, viewFlight,getAllDays, createFlight, blockFLightUnBlockFlight, deleteFLight, editFlight, autoPopulateFlightDetail } from "../../../util/constant";

const flightListing = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl + getFlight,userData,tokenDetail);
        return response?.data
    } catch (error) {
        throw(error)
    }
}
const scheduleFlightListing = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl + scheduleFlightByParentId,userData,tokenDetail);
        return response?.data
    } catch (error) {
        throw(error)
    }
}

const airportFetched = async (tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl + getAllAirport,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const aircraftFetched = async (tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl + getAllAirCraft,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}

const getALlDays = async (tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl + getAllDays,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const autoPopulateFlight = async (userData,tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl + autoPopulateFlightDetail+"/"+userData,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const flightCreate = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl + createFlight,userData,tokenDetail)
        if(response.data.message) {
            toast.success(response.data.message)
        }
        return response?.data?.data;
    } catch (error) {
        if(error.response.data.message) {
            toast.error(error.response.data.message)
        }
        throw(error)
    }
}

const updateairTaxiFLight = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl + editFlight,userData,tokenDetail)
        // if(response.data.message) {
        //     toast.success(response.data.message)
        // }
        return response?.data?.data;
    } catch (error) {
       if(error.response.data.message) {
            toast.error(error.response.data.message)
        }
        throw(error)
    }
}
const blockUnblockFlightFor = async(userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+blockFLightUnBlockFlight,userData,tokenDetail);
       
        if(response?.data?.message) {
            toast.success(response?.data?.message)
        }
        return response?.data?.data;
    } catch (error) {
        throw(error)
    }
}
const deleteFlightAirTaxi = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+deleteFLight,userData,tokenDetail);

        if(response.data.message){
            toast.success(response.data.message)
        }
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}

const viewFlightTaxi = async (userData,tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl+viewFlight+"/"+userData,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}

const singleBookedBidFire = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+getSingleForBookedSeat,userData,tokenDetail);
        return response?.data;
    } catch (error) {
        throw(error)
    }
}
const flightService = {
    flightListing,
    airportFetched,
    aircraftFetched,
    getALlDays,
    flightCreate,
    blockUnblockFlightFor,
    deleteFlightAirTaxi,
    updateairTaxiFLight,
    autoPopulateFlight,
    singleBookedBidFire,
    viewFlightTaxi,
    scheduleFlightListing
}
export default flightService
