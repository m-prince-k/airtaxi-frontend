import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import flightService from "../flight/flightService"

const initialState = {
    isError: false,
    isSuccess: false,
    isLoading: false,
    isSuccess1:"",
    isEdited: false,
    isCreator:false,
    message: "",
    flightListingDetail:"",
    allAirportDetail:"",
    allAirCraftDetail:"",
    getAllDaysDetail:"",
    createFlightDetail:"",
    flightBlockUnBlock:"",
    deleteFlightDetail:"",
    updateFlightDetail:"",
    autoPopulateDetail:"",
    isSingleBid:false,
    isSingleBlockBidDetail:"",
    viewFlightDetail:"",
    viewScheduleDetail:"",
    isViewSchedule:false
}

export const flightListingGet = createAsyncThunk('get/view',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.flightListing(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const sheduleFlightViewListing = createAsyncThunk('get/shedulelisting',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.scheduleFlightListing(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const flightDelete = createAsyncThunk('get/deleteFlighttaxi',async (userData,thunkApi)=>{
    try {
     
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.deleteFlightAirTaxi(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const autoPopulateFlightDetail = createAsyncThunk('get/autoPopulate',async (userData,thunkApi)=>{
    try {
     
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.autoPopulateFlight(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const getALlAirport = createAsyncThunk('get/allAirport',async(_,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.airportFetched(tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const getAllweekendDays = createAsyncThunk('get/allweekendday',async(_,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.getALlDays(tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});


export const getALlAircraft = createAsyncThunk('get/allAircraft',async(_,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.aircraftFetched(tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const createAirTaxiFlight = createAsyncThunk('get/createFlight',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.flightCreate(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const airTaxiUpdateFlight = createAsyncThunk('get/updateFlight',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.updateairTaxiFLight(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const blockUnblockFlight = createAsyncThunk('get/blockunblocFlight',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.blockUnblockFlightFor(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})


export const singleBookedFlightBid = createAsyncThunk('get/singleBooked',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.singleBookedBidFire(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})


export const viewFlightAirTaxi = createAsyncThunk('get/viewFlight',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await flightService.viewFlightTaxi(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})

export const flightReducer = createSlice({
    name:'admin-flight',
    initialState,
    reducers:{
        logout:(state)=>{
            state.isError=false;
            state.isLoading=false;
            state.isSuccess=false;
            state.ised=false;
            state.message="";
            state.flightListingDetail="";
            state.allAirCraftDetail="";
            state.getAllDays="";
            state.flightListingDetail="";
            state.flightBlockUnBlock="";
            state.updateFlightDetail="";
            state.autoPopulateDetail="";
            state.isCreator="";
            state.isSingleBlockBidDetail=""
            state.isEdited=false
            state.viewScheduleDetail=""
            state.isViewSchedule=false
        }
    },
    extraReducers:(builder) => {
        builder.addCase(flightListingGet.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(flightListingGet.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess1=true
            state.flightListingDetail=action.payload
        }).addCase(flightListingGet.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(getALlAirport.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(getALlAirport.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.allAirportDetail=action.payload
        }).addCase(getALlAirport.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(getALlAircraft.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(getALlAircraft.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.allAirCraftDetail=action.payload
        }).addCase(getALlAircraft.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(getAllweekendDays.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(getAllweekendDays.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.getAllDaysDetail=action.payload
        }).addCase(getAllweekendDays.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(createAirTaxiFlight.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
            state.isCreator=false
            state.message=""
        }).addCase(createAirTaxiFlight.fulfilled,(state,action) => {
            state.isLoading=false
            state.isCreator=true
            state.message="Flight Created Succcessfully"
        }).addCase(createAirTaxiFlight.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isCreator=false
        }).addCase(blockUnblockFlight.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(blockUnblockFlight.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.flightBlockUnBlock=action.payload
        }).addCase(blockUnblockFlight.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(flightDelete.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(flightDelete.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.deleteFlightDetail=action.payload
        }).addCase(flightDelete.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(airTaxiUpdateFlight.pending,(state) => {
            state.isEdited=false
            state.isLoading=true
            state.message=""
        }).addCase(airTaxiUpdateFlight.fulfilled,(state,action) => {
            state.isLoading=false
            state.isEdited=true
            state.message="Flight has been updated Successfully"
        }).addCase(airTaxiUpdateFlight.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isEdited=false
        }).addCase(autoPopulateFlightDetail.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
            state.message=""
            state.autoPopulateDetail=""
        }).addCase(autoPopulateFlightDetail.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.autoPopulateDetail=action.payload
            state.message="auto populate fetched single"
        }).addCase(autoPopulateFlightDetail.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(singleBookedFlightBid.pending,(state) => {
            state.isLoading=true
            state.isSingleBid=false
            state.isSingleBid=false
        }).addCase(singleBookedFlightBid.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSingleBid=true
            state.isSingleBlockBidDetail=action.payload
            state.message="single Booked Bid fetched Successfully"
        }).addCase(singleBookedFlightBid.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(viewFlightAirTaxi.pending,(state) => {
            state.isLoading=true
            state.isSingleBid=false
        }).addCase(viewFlightAirTaxi.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSingleBid=true
            state.viewFlightDetail=action.payload
            state.message="view flight detail fetched successfull"
        }).addCase(viewFlightAirTaxi.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(sheduleFlightViewListing.pending,(state) => {
            state.isLoading=true
            state.isViewSchedule=false
            state.message=""
        }).addCase(sheduleFlightViewListing.fulfilled,(state,action) => {
            state.isLoading=false
            state.isViewSchedule=true
            state.viewScheduleDetail=action.payload
            state.message="schedule fetched successfully"
        }).addCase(sheduleFlightViewListing.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isViewSchedule=false
        })
        
    }
});

export const { reset } = flightReducer.actions;
export default flightReducer.reducer