import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { developmentBaseUrl, forgotPasswordBySuperAdmin,resetPasswordBySuperAdmin } from "../../../util/constant";

const forgotPasswordService=async (userData) => {
    try {
      
        let response=await axios.post(developmentBaseUrl + forgotPasswordBySuperAdmin,userData)
        if(response.data.message) {
            toast.success(response.data.message)
        }
        
        return response?.data;
    } catch (error) {
        if(error.response.data.message) {
            toast.error(error.response.data.message)
        }
        throw error;
    }
}
const resetPassword=async (token,userData) => {
    try {
        let response=await axios.post(developmentBaseUrl+resetPasswordBySuperAdmin+"/"+token,userData);
        if(response.data.message){
            toast.success(response.data.message)   
        }
        return response?.data?.data 
    } catch (error) {
        if(error.response.data.message) {
            toast.error(error.response.data.message)
        }
        throw error;
    }
}
const forgotService ={forgotPasswordService,resetPassword}
export default forgotService;