import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";
import forgotService from "./forgotService";

const initialState = {
    isError: false,
    isSuccess: false,
    isLoading: false,
    message: "",
    forgotDetail: "",
    resetDetail:""
}
export const adminForgotPassword = createAsyncThunk('post/forgotPassword',async (userData,thunkApi)=>{
    try {
        return await forgotService.forgotPasswordService(userData)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});
export const resetPassword=createAsyncThunk('post/resetPassword',async (userData,thunkApi) => {
    try {
       
        let token=userData.token;
        delete userData?.token
        return await forgotService.resetPassword(token,userData)   
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})
export const forgotReducer = createSlice({
    name:'admin-forgotPassword',
    initialState,
    reducers:{
        logout:(state)=>{
            state.isError=false;
            state.isLoading=false;
            state.isSuccess=false;
            state.message="";
            state.forgotDetail="";
            state.resetDetail="";
        }
    },
    extraReducers:(builder) => {
        builder.addCase(adminForgotPassword.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(adminForgotPassword.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.forgotDetail=action.payload
        }).addCase(adminForgotPassword.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(resetPassword.pending,(state)=> {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(resetPassword.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.resetDetail=action.payload
        }).addCase(resetPassword.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        })
    }
});

export const { reset } = forgotReducer.actions;
export default forgotReducer.reducer
