import axios from "axios";
import { developmentBaseUrl ,superAdminLogin, blockUnblockUser} from "../../../util/constant";

const loginData=async (loggerData) => {
    try {
        let response=await axios.post(developmentBaseUrl + superAdminLogin,loggerData)
        if(response?.data?.data?.token){
            localStorage.setItem("authLogger",JSON.stringify(response?.data?.data?.token))
        }
        return await response?.data?.data;
    } catch (error) {
        throw error;
    }
}
const statusUpdatebyActiveDisActive=async (userData,tokenDetail) => {
    const token=tokenDetail
    try {
        let response = await axios.post(developmentBaseUrl+blockUnblockUser,userData,tokenDetail)
        return response?.data?.data
    } catch (error) {
        throw error;
    }
}
const authLogout=() => {
    localStorage.removeItem("admin")
}
const authSerivce ={loginData,authLogout,statusUpdatebyActiveDisActive}
export default authSerivce;