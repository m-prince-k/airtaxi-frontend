import { createSlice ,createAsyncThunk } from "@reduxjs/toolkit";
import authSerivce from "./authService";
const initialState = {
    isError:false,
    isSuccess:false,
    isLoading:false,
    message:"",
    loginDetail:"",
    statueDetail:""
}
export const loginPost = createAsyncThunk("adminLogin",async(userData,thunkApi) => {
    try {
        return await authSerivce.loginData(userData);
    } catch (error) {
        const message = (error.response.data) || error.response.data.message ||  error.string()
        return thunkApi.rejectWithValue(message)
    }
});
export const statusActiveDisActive=createAsyncThunk("post/status",async (userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"));
        const tokenDetail={headers:{Authorization:`Bearer ${token}`}};
        return await authSerivce.statusUpdatebyActiveDisActive(userData,tokenDetail)   
    } catch (error) {
        const message=(error.response.data && error.response.data.message) || error.string();
        return thunkApi.rejectWithValue(message)
    }
})
export const logoutAdmin = createAsyncThunk("post/logout",async (_,thunkApi) => {
    try {
        return authSerivce.authLogout();
    } catch (error) {
        const message=(error.response.data) || error.response.data.message  || error.string();
        return thunkApi.rejectWithValue(message)
    }
});

export const authReducer = createSlice({
    name:'auth-admin',
    initialState,
    reducers:{
        logout:(state)=>{
            state.isError=false;
            state.isLoading=false;
            state.isSuccess=false;
            state.message="";
            state.loginDetail="";
            state.statueDetail=""
        }
    },
    extraReducers:(builder) => {
        builder.addCase(loginPost.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(loginPost.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.loginDetail=action.payload
        }).addCase(loginPost.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(statusActiveDisActive.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(statusActiveDisActive.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.statueDetail=action.payload
        }).addCase(statusActiveDisActive.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(logoutAdmin,(state) => {
            state.loginDetail=null
            logout()
        })
    }
});
export const {logout}=authReducer.actions
export default authReducer.reducer
