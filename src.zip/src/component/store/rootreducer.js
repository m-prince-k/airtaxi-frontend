import { combineReducers } from "@reduxjs/toolkit";
import authSlice from "./login/authSlice";
import forgotSlice from "./forgotPassword/forgotSlice";
import employeeSlice from "./employee/employeeSlice";
import userSlice from "./user/userSlice";
import dashboardSlice from "./dashboard/dashboardSlice";
import flightSlice from "./flight/flightSlice";
import aircraftSlice from "./aircraft/aircraftSlice";

const rootReducer=combineReducers({
auth:authSlice,
forgotauth:forgotSlice,
employee:employeeSlice,
user:userSlice,
dashboard:dashboardSlice,
flight:flightSlice,
aircraft:aircraftSlice
});
export default rootReducer