import axios from "axios";
import { toast } from "react-toastify";
import { otpSend, verifyOtp,developmentBaseUrl, getUserListing ,addUser, getUserProfile, blockUnblockUser,changePasswordForUser,editProfile,deleteUser,viewUser,getFilledUser,editUser} from "../../../util/constant";
const userListing = async(tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl+getUserListing,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const deleteUserAdmin = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+deleteUser,userData,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}

const otpSendForChangePassword = async (userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+otpSend,userData,tokenDetail);
        console.log('++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++',response?.data);
        if(response?.data?.message) {
            return toast.success(response?.data?.message)
        }
        return response?.data;
    } catch (error) {
        throw(error)
    }
}


const viewUserAdmin=async (userData,tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl+viewUser+"/"+userData,tokenDetail);
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const blockUnblockUserForAdmin = async(userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+blockUnblockUser,userData,tokenDetail);
        console.log('response *********************************',response)
        if(response?.data?.message) {
            toast.success(response?.data?.message)
        }
        return response?.data?.data;
    } catch (error) {
        throw(error)
    }
}

const changePassword = async(userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+changePasswordForUser,userData,tokenDetail);
       
        if(response.data.message){
            toast.success(response.data.message)
        }
        return response?.data?.data;
    } catch (error) {
        console.log('++++++++++++++++++*******************************************error',error)
        if(error.response.data.message) {
            toast.error(error.response.data.message)
        }
        throw(error)
    }
}

const verifyOtpForChangePassword = async(userData,tokenDetail) => {
    try {
        const response = await axios.post(developmentBaseUrl+verifyOtp,userData,tokenDetail);
        if(response.data.message){
            toast.success(response.data.message)
        }
        return response?.data?.data;
    } catch (error) {
        if(error.response.data.message) {
            toast.error(error.response.data.message)
        }
        throw(error)
    }
}


const getProfile=async (tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl+getUserProfile,tokenDetail);
        return response?.data?.data;
    } catch (error) {
        throw(error)
    }
}
const editAuthProfile=async (userData,tokenDetail) => {
    try {
        
        let form=new FormData();
        form.append("first_name",userData.first_name)
        form.append("last_name",userData.last_name)
        form.append("country_code",userData.country_code)
        form.append("phone_number",userData.phone_number)
        form.append("email",userData.email)
        form.append("location",userData.location)
        form.append("profile_pic",userData.profile_pic)

        const response = await axios.post(developmentBaseUrl+editProfile,form,tokenDetail);

        if(response.data.message){
            toast.success(response.data.message)
        }
        return response?.data?.data;
    } catch (error) {
        if(error.response.data.message) {
            toast.error(error.response.data.message)
        }
        throw(error)
    }
}
const autoFilledUser = async (userData,tokenDetail) => {
    try {
        const response = await axios.get(developmentBaseUrl + getFilledUser+"/"+userData,tokenDetail);
        return response?.data?.data
    } catch (error) {
        console.log('_____________________________________error',error);
        throw(error)
    }
}

const editUserAdmin= async (userData,userId,tokenDetail) => {
    try {
        const form=new FormData();
        form.append("first_name",userData.first_name);
        form.append("last_name",userData.last_name);
        form.append("email",userData.email);
        form.append("country_code",userData.country_code);
        form.append("phone_number",userData.phone_number);
        form.append("location",userData.location);
        form.append("profile_pic",userData.profile_pic)
        form.append("id",userId)
        const response = await axios.post(developmentBaseUrl + editUser,form,tokenDetail);
        return response?.data?.data && response?.data
    } catch (error) {
        console.log('_____________________________________error',error);
        throw(error)
    }
}


const userCreate=async(userData,tokenDetail) => {
    try {
        let form = new FormData();
        form.append("first_name",userData.first_name)
        form.append("last_name",userData.last_name)
        form.append("email",userData.email)
        form.append("password",userData.password)
        form.append("location",userData.location)
        form.append("profile_pic",userData.profile_pic)
        form.append("user_role",userData.user_role)
        form.append("country_code",userData.country_code)
        form.append("phone_number",userData.phone_number)
        const response=await axios.post(developmentBaseUrl+addUser,form,tokenDetail);
        console.log('______________________________form is here',response)
        return response?.data?.data
    } catch (error) {
        throw(error)
    }
}
const getAllUserListing = {
    userListing,
    userCreate,
    getProfile,
    blockUnblockUserForAdmin,
    deleteUserAdmin,
    viewUserAdmin,
    autoFilledUser,
    editUserAdmin,
    editAuthProfile,
    changePassword,
    otpSendForChangePassword,
    verifyOtpForChangePassword
}
export default getAllUserListing;