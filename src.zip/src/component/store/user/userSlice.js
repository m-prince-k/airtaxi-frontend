import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";
import getAllUserListing from "./userService";
const initialState = {
    isError: false,
    isSuccess: false,
    isLoading: false,
    message: "",
    userDetails: "",
    createEmployee:"",
    createMessage:"",
    deleteUserDetail:"",
    profileDetail:"",
    isProfileUpdated:"",
    blockUnblockUserDetail:"",
    autoFilledUserDetail:"",
    updateUserDetail:"",
    viewSingleDetail:"",
    editProfileDetail:"",
    changePasswordDetail:"",
    otpSendDetail:"",
    OtpVerifyDetail:""
}
export const viewDetail = createAsyncThunk('get/view',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllUserListing.viewUserAdmin(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})
export const blockUnblockUser = createAsyncThunk('get/blockunblockuser',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllUserListing.blockUnblockUserForAdmin(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})

export const changePasswordUser = createAsyncThunk('get/changePassword',async(userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllUserListing.changePassword(userData,tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})


export const getAllUserBySuperAdmin = createAsyncThunk('get/userListing',async (_,thunkApi)=>{
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllUserListing.userListing(tokenDetails)
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});


export const otpSentToChange = createAsyncThunk('get/otpsend',async (userData,thunkApi)=>{
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllUserListing.otpSendForChangePassword(userData,tokenDetails)
    } catch (error) {
        const message=error.response.data || error.string();
        return thunkApi.rejectWithValue(message)
    }
});


export const deleteUser = createAsyncThunk('get/deleteEmp',async (userData,thunkApi)=>{
    try {
     
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllUserListing.deleteUserAdmin(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});
export const getAuthProfile = createAsyncThunk('get/profileDetail',async (_,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllUserListing.getProfile(tokenDetails);   
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const updateAuthProfile = createAsyncThunk('get/editProfile',async (userData,thunkApi) => {
    try {
     
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{
            "Content-Type":"multipart/form-data",
            Authorization:`Bearer ${token}`}
        }
        return await getAllUserListing.editAuthProfile(userData,tokenDetails);   
    } catch (error) {
        const message=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});

export const addEmployeeUser =createAsyncThunk('post/createEmployee',async (userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"));
        const tokenDetails={headers:{
           'Content-Type': 'multipart/form-data',
            Authorization:`Bearer ${token}`,
            },
        }
        return await getAllUserListing.userCreate(userData,tokenDetails)
    } catch (error) {
        const createMessage=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(createMessage)
    }
});

export const verifyOtpCPassword =createAsyncThunk('post/otpverify',async (userData,thunkApi) => {
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"));
        const tokenDetails={headers:{
            Authorization:`Bearer ${token}`,
            },
        }
        return await getAllUserListing.verifyOtpForChangePassword(userData,tokenDetails)
    } catch (error) {
        const createMessage=(error.response && error.response.data) || error.response.data.message || error.string()
        return thunkApi.rejectWithValue(createMessage)
    }
});


export const editUser=createAsyncThunk ('update/employee',async (userData,thunkApi) => {
    try {
        let userId=userData.id
       
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{
            'Content-Type': 'multipart/form-data',
            Authorization:`Bearer ${token}`}
        }
        return await getAllUserListing.editUserAdmin(userData,userId,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
})

export const autoFilledUser = createAsyncThunk('get/autofilled',async (userData,thunkApi)=>{
    try {
        let token=JSON.parse(localStorage.getItem("authLogger"))
        const tokenDetails={headers:{Authorization:`Bearer ${token}`}}
        return await getAllUserListing.autoFilledUser(userData,tokenDetails)
    } catch (error) {
        const message=error.response && error.response.data || error.response.message || error.string()
        return thunkApi.rejectWithValue(message)
    }
});


export const userReducer = createSlice({
    name:'admin-user',
    initialState,
    reducers:{
        logout:(state)=>{
            state.isError=false;
            state.isLoading=false;
            state.isSuccess=false;
            state.message="";
            state.userDetails="";
            state.createEmployee="";
            state.createMessage="";
            state.deleteUserDetail="";
            state.profileDetail="";
            state.blockUnblockUserDetail="";
            state.autoFilledUserDetail="";
            state.updateUserDetail="";
            state.viewSingleDetail="";
            state.editProfileDetail="";
            state.changePasswordDetail=""
            state.otpSendDetail="";
            state.OtpVerifyDetail="";
            state.isProfileUpdated="";
        }
    },
    extraReducers:(builder) => {
        builder.addCase(getAllUserBySuperAdmin.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(getAllUserBySuperAdmin.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.userDetails=action.payload
            state.message="All User By Admin"
        }).addCase(getAllUserBySuperAdmin.rejected,(state,action)=> {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(addEmployeeUser.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(addEmployeeUser.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.createEmployee=action.payload
            state.message='Employee Created Successfully'
        }).addCase(addEmployeeUser.rejected,(state,action) => {
            state.isLoading=true
            state.createMessage=action.payload
            state.isSuccess=false
        }).addCase(deleteUser.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(deleteUser.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.deleteUserDetail=action.payload
            state.message=action.payload
        }).addCase(deleteUser.rejected,(state,action) => {
            state.isLoading=true
            state.createMessage=action.payload
        }).addCase(getAuthProfile.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(getAuthProfile.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.profileDetail=action.payload
            state.message="profile get successfully"
        }).addCase(getAuthProfile.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(blockUnblockUser.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(blockUnblockUser.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.blockUnblockUserDetail=action.payload
            state.message="profile get successfully"
        }).addCase(blockUnblockUser.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(autoFilledUser.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(autoFilledUser.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.autoFilledUserDetail=action.payload
            state.message="auto filled user successfuly fetched"
        }).addCase(autoFilledUser.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(editUser.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(editUser.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.updateUserDetail=action.payload
            state.message="getch updated user record"
        }).addCase(editUser.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(viewDetail.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(viewDetail.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.viewSingleDetail=action.payload
            state.message="view Detail fetched successfully !"
        }).addCase(viewDetail.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(updateAuthProfile.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(updateAuthProfile.fulfilled,(state,action) => {
            state.isLoading=false
            state.isProfileUpdated=true
            state.editProfileDetail=action.payload
            state.message="Profile has been updated successfully"
        }).addCase(updateAuthProfile.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isProfileUpdated=false
        }).addCase(changePasswordUser.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(changePasswordUser.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.changePasswordDetail=action.payload
            state.message="Password has been Changes successfully"
        }).addCase(changePasswordUser.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(otpSentToChange.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(otpSentToChange.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.otpSendDetail=action.payload
            state.message="otp has been sent successfully"
        }).addCase(otpSentToChange.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        }).addCase(verifyOtpCPassword.pending,(state) => {
            state.isLoading=true
            state.isSuccess=false
        }).addCase(verifyOtpCPassword.fulfilled,(state,action) => {
            state.isLoading=false
            state.isSuccess=true
            state.OtpVerifyDetail=action.payload
            state.message="OTP has been verified successfully"
        }).addCase(verifyOtpCPassword.rejected,(state,action) => {
            state.isLoading=true
            state.message=action.payload
            state.isSuccess=false
        })

        

        
    }
});

export const { reset } = userReducer.actions;
export default userReducer.reducer
