import React from 'react'

export default function Thanks() {
  return (
    <div><h1>Thanks for Reset the Password</h1></div>
  )
}
