import axios from 'axios';
import React, { useState } from 'react'

export default function useFetch() {
    const [apiResult,setData]=useState("");
    const ApiMethod = async(obj) => {
        let options = {
            url:obj.url,
            method:obj.method,
            headers:{
                "Accept":"application/json",
                "Content-Type":"application/json;chartset:Utf-8;"                 
            }
        }
        const response=await axios(options);
        const responseOk=response && response?.data ||  response?.statusCode===200;
        if(responseOk)
        setData(response?.data)
    }
    return [apiResult,ApiMethod];
}

