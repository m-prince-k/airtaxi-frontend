import React, { useEffect, useRef, useState } from 'react'
import SideBar from '../../component/sidebar/sidebar'
import ToasterContainer from '../../component/toastify/ToasterContainer'
import Topbar from '../../component/topbar/topbar'
import '@coreui/coreui/dist/css/coreui.min.css'
import { CForm, CButton, CFormInput, CFormSwitch, CInputGroup, CModal, CModalBody, CModalFooter, CFormSelect } from '@coreui/react'
import { getALlAirport } from '../../component/store/flight/flightSlice'
import { useDispatch, useSelector } from 'react-redux';
import { createAirCraft } from '../../component/store/aircraft/aircraftSlice'
import { Box, CircularProgress, TextField } from '@material-ui/core'
import { useNavigate } from 'react-router-dom'
import { useFormik } from "formik";
import * as yup from "yup";
import { toast } from 'react-toastify'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import moment from "moment";


export default function AddAirCraft() {
    const [values, setValue] = useState({
        aircraft_model: "",
        year_of_manufacture: "",
        msn: "",
        registeration_mark: "",
        date_inducted: "",
        no_pilot_seat: "",
        pilot: "",
        no_of_passenger_seat: "",
        night_parking_base: "",
        baggage_capacity: ""
    });
    const [disabledBtn,setDisabledBtn]=useState(false)
    const [startDate, setStartDate] = useState(new Date());
    const [Validations, setValidations] = useState({
        aircraft_model: "",
        year_of_manufacture: "",
        msn: "",
        registeration_mark: "",
        date_inducted: "",
        no_pilot_seat: "",
        pilot: "",
        no_of_passenger_seat: "",
        night_parking_base: "",
        baggage_capacity: ""
    });
    const [loader, setLoader] = useState(false);

    const schema = yup.object().shape({
        aircraft_model: yup.string().required("Please enter the aircraft model"),
        // year_of_manufacture:yup.string().required("Please enter the year of manufature"),
        msn: yup.string().required("Please enter the manufacture serial number"),
        registeration_mark: yup.string().required("Please enter the registeration mark"),
        date_inducted: yup.date().required("Please select the date"),

        no_pilot_seat: yup.number("enter the valid").required("Please enter the no of pilot seat"),
        no_of_passenger_seat: yup.string().required('Please enter the no of passenger seat').typeError('A number is required'),
        pilot: yup.string().required("Please select the pilot"),
        night_parking_base: yup.string().required("Please select the night parking base"),
        baggage_capacity: yup.number().min(1, "Please enter min 6 character").required("Please select the baggage capacity")
    });

    let _Fields = { aircraft_model: "", year_of_manufacture: "", msn: "", registeration_mark: "", date_inducted: "", no_pilot_seat: "", no_of_passenger_seat: "", pilot: "", night_parking_base: "", baggage_capacity: "" }

    const navigatge = useNavigate();
    const [validated, setValidated] = useState(false)
    const [airport, setAirport] = useState("")
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const { allAirportDetail, isSuccess } = useSelector((state) => state.flight);
    const { creationAircraft, isAirCreator, isUpdateCraator, message: resMessage } = useSelector((state) => state.aircraft)

    const previousProps = useRef({ isAirCreator }).current;

    useEffect(() => {
        if (previousProps?.isAirCreator !== isAirCreator) {
            if (isAirCreator) {
                
                setLoader(true)
                toast.success(resMessage)
                setTimeout(() => {
                    navigate("/aircraftListing")
                }, 2000);

            } else if (!isAirCreator && resMessage) {
                toast.error("something went wrong")
            }
        }
        return () => {
            previousProps.isAirCreator = isAirCreator;
        };
    }, [isAirCreator, resMessage])

    useEffect(() => {
        dispatch(getALlAirport());
    }, [])

    useEffect(() => {
        if (isSuccess && allAirportDetail) {
            setAirport(allAirportDetail)
        }
    }, [isSuccess, allAirportDetail])

    const handleChange = (e) => {
        const { name, value } = e.target;
        setValue({ ...values, [name]: value })
    }

    const handleSubmit = (event) => {
        event.preventDefault();

        const isValid = validateAll();
        if (!isValid) { return false; }
        setDisabledBtn(true)
        let payloadAircraft = {
            aircraft_model: values.aircraft_model,
            year_of_manufacture: values.year_of_manufacture,
            msn: values.msn,
            registeration_mark: values.registeration_mark,
            date_inducted: moment(startDate).format("YYYY-MM-DD"),
            no_pilot_seat: values.no_pilot_seat,
            no_passenger_seat: values.no_of_passenger_seat,
            pilot: values.pilot,
            night_parking_base: values.night_parking_base,
            baggage_capacity: values.baggage_capacity
        }
        //console.log('*******************************************payload is here',payloadAircraft)
        dispatch(createAirCraft(payloadAircraft))

        setValue({
            aircraft_model: "",
            year_of_manufacture: "",
            msn: "",
            registeration_mark: "",
            date_inducted: "",
            no_pilot_seat: "",
            pilot: "",
            no_of_passenger_seat: "",
            night_parking_base: "",
            baggage_capacity: ""
        })

    }

    //   const formik=useFormik({
    //     initialValues:_Fields,
    //     validationSchema:schema,
    //     onSubmit:handleSubmit,
    //     onChange:handleChange
    // });


    const validateAll = () => {
        let isValid = true;
        const Validations = {};
        if (!values.aircraft_model) {
            Validations.aircraft_model = "Please enter the aircraft model"
            isValid = false
        } 

        if (!values.year_of_manufacture) {
            Validations.year_of_manufacture = "Please enter the year of manufacture"
            isValid = false
        }

        if(values.year_of_manufacture.length > 4){
			Validations.year_of_manufacture='Please enter the valid year of manufacture'
			isValid=false
		}

        if(!values.year_of_manufacture.match(/^\d+(?:\.\d+)?$/)){
        	Validations.year_of_manufacture='Please enter the valid year of manufacture'
        	isValid=false
        }

        if (!values.msn) {
            Validations.msn = "Please enter the msn"
            isValid = false
        }

        if (!values.registeration_mark) {
            Validations.registeration_mark = "Please enter the registration mark"
            isValid = false
        }
        if (!startDate) {
            Validations.date_inducted = 'Please select the date inducted'
            isValid = false
        }

        // if(!values.date_inducted.match(/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/)){
        // 	Validations.date_inducted='Please enter the valid date inducted'
        // 	isValid=false
        // }
    
        if (!values.no_pilot_seat) {
            Validations.no_pilot_seat = 'Please enter the number of pilot seats'
            isValid = false
        }

        if(!values.no_pilot_seat.match(/^\d+(?:\.\d+)?$/)){
        	Validations.no_pilot_seat='Please enter the valid number of pilot seats'
        	isValid=false
        }

        if (!values.no_of_passenger_seat) {
            Validations.no_of_passenger_seat = 'Please enter the number of passenger seat'
            isValid = false
        }

        if(!values.no_of_passenger_seat.match(/^\d+(?:\.\d+)?$/)){
        	Validations.no_of_passenger_seat='Please enter the valid number of passenger seat'
        	isValid=false
        }

        if (!values.pilot) {
            Validations.pilot = 'Please select the pilot'
            isValid = false
        }
        if (!values.night_parking_base) {
            Validations.night_parking_base = 'Please enter the night parking base'
            isValid = false
        }
        if (!values.baggage_capacity) {
            Validations.baggage_capacity = 'Please enter the baggage capacity'
            isValid = false
        }
        if(values.baggage_capacity.length > 10){
			Validations.baggage_capacity='Please enter the at least limited baggage capacity'
			isValid=false
		}
     
         if(!values.baggage_capacity.match(/^\d+(?:\.\d+)?$/) && !values.baggage_capacity.match(/^[0-9]{0,2}$/)){
        	Validations.baggage_capacity='Please enter the valid baggage capacity should not be negative and only number'
        	isValid=false
        }

        if (!isValid) {
            setValidations(Validations)
        }
        return isValid;
    }

    return (
        <div>
            <ToasterContainer />
            <div className='wrapper'>
                <SideBar />
                <div className='main'>
                    <Topbar />
                    <main className="d-flex w-100">
                        <div className="container d-flex flex-column">
                            <div className="row">
                                <div className="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
                                    <div className="d-table-cell align-middle">
                                        <div className="text-center mt-4">
                                            <h1 className="h2">Create an AirCraft</h1>
                                            {/* card body start here for adding aircraft */}
                                            <div className="card">
                                                <div className="card-body">

                                                    <div className="m-sm-4">
                                                        <CForm validated={validated} className="row g-3 needs-validation"
                                                            noValidate onSubmit={(event) => handleSubmit(event)}>
                                                            <div className="mb-3 text-start">
                                                                <label className="form-label mb-3">Aircraft Model*</label>
                                                                <CFormInput
                                                                    feedbackValid="Looks good!"
                                                                    id="validationTooltip01"
                                                                    label=""
                                                                    required
                                                                    tooltipFeedback
                                                                    className="form-control form-control-lg"
                                                                    type="text" maxLength={50} onChange={handleChange} value={values.aircraft_model} name="aircraft_model" placeholder="Enter the aircraft model" />
                                                                <h6 style={{ color: 'red' }}>{Validations.aircraft_model ? Validations.aircraft_model : ''}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Year of Manufacturing*</label>
                                                                <input className="form-control form-control-lg" type="text" onChange={handleChange} name="year_of_manufacture" value={values.year_of_manufacture} placeholder="Enter year of manufacture" />
                                                                <h6 style={{ color: 'red' }}>{Validations.year_of_manufacture ? Validations.year_of_manufacture : ''}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">MSN (Manufacturer's Serial Number)*</label>
                                                                <input className="form-control form-control-lg" type="text" maxLength={50} onChange={handleChange} name="msn" value={values.msn} placeholder="Enter the manufacturer serial number" />
                                                                <h6 style={{ color: 'red' }}>{Validations.msn}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Registration Mark*</label>
                                                                <input className="form-control form-control-lg" type="text" maxLength={50} onBlur="" onChange={handleChange} name="registeration_mark" value={values.registeration_mark} placeholder="Enter the registration mark" />
                                                                <h6 style={{ color: 'red' }}>{Validations.registeration_mark}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Date Inducted*</label><br/>
                                                                <DatePicker selected={startDate} maxDate={new Date()} onKeyDown={(e) => {e.preventDefault(); }}  className="form-control" value={startDate}  name="date_inducted" onChange={(date) => setStartDate(date)} />
                                                                {/* <TextField id="date" label="" onChange={handleChange} type="date" name="date_inducted" value={values.date_inducted} InputLabelProps={{ shrink: true, required: true }} defaultValue={new Date().toISOString().substring(0, 10)} /> */}
                                                                <br />
                                                                <h6 style={{ color: 'red' }}>{Validations.date_inducted}</h6>
                                                            </div>
                                                            {
                                                                loader &&
                                                                <div style={{ marginLeft: "0px" }}>
                                                                    <Box sx={{ display: 'flex' }}><CircularProgress /></Box>
                                                                </div>
                                                            }
                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Number of Pilot Seats*</label>
                                                                <input className="form-control form-control-lg" type="text" maxLength={50} onBlur="" onChange={handleChange} name="no_pilot_seat" value={values.no_pilot_seat} placeholder="Enter the pilot seats" />
                                                                <h6 style={{ color: 'red' }}>{Validations.no_pilot_seat}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Number of Passenger Seat*</label>
                                                                <input className="form-control form-control-lg" type="text" maxLength={50} onBlur="" onChange={handleChange} name="no_of_passenger_seat" value={values.no_of_passenger_seat} placeholder="Enter the no of passenger seat" />
                                                                <h6 style={{ color: 'red' }}>{Validations.no_of_passenger_seat}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Pilot*</label>
                                                                <CFormSelect
                                                                    aria-describedby="validationTooltip04Feedback"
                                                                    feedbackInvalid="Please select a valid state."
                                                                    id="validationTooltip04"
                                                                    label=""
                                                                    required
                                                                    name="pilot"
                                                                    value={values.pilot}
                                                                    tooltipFeedback
                                                                    onChange={handleChange}
                                                                >
                                                                    <option selected="" disabled={true} value="">
                                                                        Choose...
                                                                    </option>
                                                                    <option value="Single Pilot">Single Pilot</option>
                                                                    <option value="Multi Crew">Multi Crew</option>
                                                                </CFormSelect>
                                                                <h6 style={{ color: 'red' }}>{Validations.pilot}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Night Parking Base*</label>
                                                                <CFormSelect
                                                                    aria-describedby="validationTooltip04Feedback"
                                                                    feedbackInvalid="Please select a valid state."
                                                                    id="validationTooltip04"
                                                                    label=""
                                                                    required
                                                                    value={values.night_parking_base}
                                                                    name="night_parking_base"
                                                                    onChange={handleChange}
                                                                    tooltipFeedback
                                                                >
                                                                    <option selected="" disabled="">
                                                                        Choose...
                                                                    </option>
                                                                    <option value="Single Pilot" disabled>select the airport</option>
                                                                    {
                                                                        airport && airport.map((option) => {
                                                                            return (
                                                                                <option key={option.id} value={option.airport_name}>{option?.airport_name}</option>
                                                                            );
                                                                        })
                                                                    }
                                                                </CFormSelect>
                                                                <h6 style={{ color: 'red' }}>{Validations.night_parking_base}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Baggage Capacity* (in Kg)</label>
                                                                <div className='position-relative'>
                                                                    <input
                                                                        type="text"
                                                                       className='form-control'
                                                                        placeholder="Please enter the baggage capacity"
                                                                        min="0" oninput="this.value = Math.abs(this.value)"
                                                                        value={values.baggage_capacity}
                                                                        step="0.001"
                                                                        onChange={handleChange}
                                                                        name="baggage_capacity" />


                                                                    <h6 style={{ color: 'red' }}>{Validations.baggage_capacity}</h6>
                                                                </div>
                                                            </div>

                                                            <div className="mb-3">
                                                                <CButton color="primary" disabled={disabledBtn} type="submit">Submit</CButton>
                                                            </div>
                                                        </CForm>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
    )
}
