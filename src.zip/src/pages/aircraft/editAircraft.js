import React, { useEffect, useRef, useState } from 'react'
import SideBar from '../../component/sidebar/sidebar'
import ToasterContainer from '../../component/toastify/ToasterContainer'
import Topbar from '../../component/topbar/topbar'

import { getALlAirport } from '../../component/store/flight/flightSlice'
import { useDispatch, useSelector } from 'react-redux';
import { createAirCraft, autoPopulateAircraft, editAirCraft } from '../../component/store/aircraft/aircraftSlice'
import { Box, CircularProgress, TextField } from '@material-ui/core'
import { useNavigate, useParams } from 'react-router-dom'
import Datetime from "react-datetime";
import 'react-datetime/css/react-datetime.css';
import moment from "moment"
import { useFormik } from "formik";
import * as yup from "yup";
import { toast } from 'react-toastify'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";


export default function AddAirCraft() {
    const [values, setValue] = useState({
        aircraft_model: "",
        year_of_manufacture: "",
        msn: "",
        registeration_mark: "",
        date_inducted: "",
        no_pilot_seat: "",
        pilot: "",
        no_of_passenger_seats: "",
        night_parking_base: "",
        baggage_capacity: ""
    });
    const [startDate, setStartDate] = useState();
    const [Validations,setValidations]=useState({aircraft_model:"",
    year_of_manufacture:"",
    msn:"",
    registeration_mark:"",
    date_inducted:"",
    no_pilot_seat:"",
    pilot:"",
    no_of_passenger_seat:"",
    night_parking_base:"",
    baggage_capacity:""
});

    const [validated, setValidated] = useState(false)
    const [airport, setAirport] = useState("")
    const [autoPopulate, setAutoPopulate] = useState("")
    const dispatch = useDispatch();
    const params = useParams();
    const [disabledBtn,setDisabledBtn]=useState(false)

    const { allAirportDetail, isSuccess } = useSelector((state) => state.flight);
    const { autoPopulateAirCraftDetail, updateMessage, isSuccess1,isUpdateCraator,message:resMessage } = useSelector((state) => state.aircraft)
    const navigate = useNavigate();

    useEffect(() => {
        dispatch(getALlAirport());
        dispatch(autoPopulateAircraft(params.id))
    }, [])

    const previousProps=useRef({ isUpdateCraator }).current;
   

    useEffect(() => {
        if (previousProps?.isUpdateCraator !== isUpdateCraator) {
			if (isUpdateCraator) {
				
				setTimeout(() => {
					navigate("/aircraftListing")
				}, 2000);
				
			} else if (!isUpdateCraator && resMessage) {
				toast.error("something went wrong")
			}		
		}
		return () => {
			previousProps.isUpdateCraator = isUpdateCraator;
		  };
    })


    useEffect(() => {
        if (autoPopulateAirCraftDetail) {
            setAutoPopulate(autoPopulateAirCraftDetail)
        }
    }, [autoPopulateAirCraftDetail])
 
    useEffect(() => {
        if(autoPopulate) {
            setStartDate(new Date(autoPopulate?.date_inducted))
        autoPopulate && setValue({ aircraft_model: autoPopulate?.aircraft_model, year_of_manufacture: autoPopulate?.year_of_manufacture, msn: autoPopulate?.msn, registeration_mark: autoPopulate.registeration_mark, no_pilot_seat: autoPopulate.no_pilot_seats, no_of_passenger_seats: autoPopulate.no_of_passenger_seats, pilot: autoPopulate.pilot, night_parking_base: autoPopulate.night_parking_base, baggage_capacity: autoPopulate.baggage_capacity })
        }
    }, [autoPopulate]);


    useEffect(() => {
        if (isSuccess && allAirportDetail) {
            setAirport(allAirportDetail)
        }
    }, [isSuccess, allAirportDetail])

    const handleChange = (e) => {

        const { name, value } = e.target;
        setValue({ ...values, [name]: value })
    }

    const handleSubmit = (event) => {
        event.preventDefault();

        const isValid=validateAll();
		if(!isValid) {return false;}
        setDisabledBtn(true)
        let payloadAircraft = {
            aircraft_model: values.aircraft_model,
            year_of_manufacture: values.year_of_manufacture,
            msn: values.msn,
            registeration_mark: values.registeration_mark,
            date_inducted: moment(startDate).format("YYYY-MM-DD"),
            no_pilot_seats: values.no_pilot_seat,
            no_of_passenger_seats: values.no_of_passenger_seats,
            pilot: values.pilot,
            night_parking_base: values.night_parking_base,
            baggage_capacity: values.baggage_capacity,
            id: params.id
        }
        console.log('++============================================================va;lue is here', payloadAircraft)
        dispatch(editAirCraft(payloadAircraft))
    }

    // let _Fields = { aircraft_model: "", year_of_manufacture: "", msn: "", registeration_mark: "", date_inducted: "", no_pilot_seat: "", no_of_passenger_seat: "", pilot: "", night_parking_base: "", baggage_capacity: "" }
    
    // const schema = yup.object().shape({
    //     aircraft_model: yup.string().required("Please enter the aircraft model"),
    //     year_of_manufacture: yup.number().required("Please enter the year of manufature"),
    //     msn: yup.string().required("Please enter the manufacture serial number"),
    //     registeration_mark: yup.string().min(6, "Please enter min 6 character").max(14, "Please enter the max 14 char").required("Please enter the registeration mark"),
    //     date_inducted: yup.date().required("Please select the date"),

    //     no_pilot_seat: yup.number("enter the valid").min(6, "Please enter min 6 character").max(14, "Please enter the max 14 char").required("Please enter the no of pilot seat"),
    //     no_of_passenger_seat: yup.string().min(6, "Please enter min 6 character").max(14, "Please enter the max 14 char").required('Please enter the no of passenger seat').typeError('A number is required'),
    //     pilot: yup.string().required("Please select the pilot"),
    //     night_parking_base: yup.string().required("Please select the night parking base"),
    //     baggage_capacity: yup.number().min(1, "Please enter min 6 character").required("Please select the baggage capacity")
    // });


    // const formik = useFormik({
    //     initialValues: _Fields,
    //     validationSchema: schema,
    //     onSubmit: handleSubmit,
    //     onChange: handleChange
    // });




    const validateAll = () => {
		let isValid=true;
		const Validations={};
        if (!values.aircraft_model) {
            Validations.aircraft_model = "Please enter the aircraft model"
            isValid = false
        } 

        if (!values.year_of_manufacture && !values.year_of_manufacture.match(/^\d+(?:\.\d+)?$/)) {
            Validations.year_of_manufacture = "Please enter the valid year of manufacture like 2012"
            isValid = false
        }

        if(values.year_of_manufacture.length > 4){
			Validations.year_of_manufacture='Please enter the valid year of manufacture'
			isValid=false
		}

        

        if (!values.msn) {
            Validations.msn = "Please enter the msn"
            isValid = false
        }

        if (!values.registeration_mark) {
            Validations.registeration_mark = "Please enter the registration mark"
            isValid = false
        }
        if (!startDate) {
            Validations.date_inducted = 'Please select the date inducted'
            isValid = false
        }
    
        if (!values.no_pilot_seat) {
            Validations.no_pilot_seat = 'Please enter the number of pilot seats'
            isValid = false
        }

        // if(!values.no_pilot_seat.match(/^\d+(?:\.\d+)?$/)){
        // 	Validations.no_pilot_seat='Please enter the valid no pilot seat'
        // 	isValid=false
        // }

        if (!values.no_of_passenger_seats) {
            Validations.no_of_passenger_seat = 'Please enter the number of passenger seat'
            isValid = false
        }

        // if(!values.no_of_passenger_seats.match(/^\d+(?:\.\d+)?$/)){
        // 	Validations.no_of_passenger_seat='Please enter the valid no of passenger seat'
        // 	isValid=false
        // }

        if (!values.pilot) {
            Validations.pilot = 'Please select the pilot'
            isValid = false
        }
        if (!values.night_parking_base) {
            Validations.night_parking_base = 'Please enter the night parking base'
            isValid = false
        }
        if (!values.baggage_capacity) {
            Validations.baggage_capacity = 'Please enter the night parking base'
            isValid = false
        }
        if(values.baggage_capacity.length > 10){
			Validations.baggage_capacity='Please enter the at least limited baggage capacity'
			isValid=false
		} 
        // if(!values.baggage_capacity.match(/^\d+(?:\.\d+)?$/) && !values.baggage_capacity.match(/^[0-9]{0,2}$/)){
        // 	Validations.baggage_capacity='Please enter the valid baggage capacity should not be negative and only number'
        // 	isValid=false
        // }
       
		if(!isValid) {
			setValidations(Validations)
		}
		return isValid;
	}


    return (
        <div>
            <ToasterContainer />
            <div className='wrapper'>
                <SideBar />
                <div className='main'>
                    <Topbar />
                    <main className="d-flex w-100">
                        <div className="container d-flex flex-column">
                            <div className="row">
                                <div className="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
                                    <div className="d-table-cell align-middle">
                                        <div className="text-center mt-4">
                                            <h1 className="h2">Edit an AirCraft</h1>
                                            {/* card body start here for adding aircraft */}
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="m-sm-4">
                                                        <form
                                                             onSubmit={(event) => handleSubmit(event)}>
                                                            <div className="mb-3 text-start">
                                                                <label className="form-label mb-3">Aircraft Model*</label>
                                                                <input
                                                                    className="form-control form-control-lg"
                                                                    type="text" maxLength={50} onChange={handleChange} value={values.aircraft_model ? values.aircraft_model: values.aircraft_model} name="aircraft_model" placeholder="Enter the aircraft model" />
                                                             <h6 style={{color:'red'}}>{Validations.aircraft_model}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Year of Manufacturing*</label>
                                                                <input className="form-control form-control-lg" type="text" onChange={handleChange} maxLength={30} name="year_of_manufacture" value={values.year_of_manufacture ? values.year_of_manufacture : values.year_of_manufacture} placeholder="Enter the year of manufacture" />
                                                                <h6 style={{color:'red'}}>{Validations.year_of_manufacture}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">MSN (Manufacturer's Serial Number)*</label>
                                                                <input className="form-control form-control-lg" type="text" maxLength={50} onBlur="" onChange={handleChange ? handleChange :  handleChange} name="msn" value={values.msn ? values.msn :  values.msn} placeholder="Enter the manufacturer serial number" />
                                                                <h6 style={{color:'red'}}>{Validations.msn}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Registration Mark*</label>
                                                                <input className="form-control form-control-lg" type="text" maxLength={50} onBlur="" onChange={handleChange ? handleChange : handleChange} name="registeration_mark" value={values.registeration_mark ? values.registeration_mark : values.registeration_mark} placeholder="Enter the registeration mark" />
                                                                <h6 style={{color:'red'}}>{Validations.registeration_mark}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Date Inducted*</label><br />
                                                                <DatePicker  onKeyDown={(e) => {e.preventDefault(); }} selected={startDate}  className="form-control" value={startDate}  name="date_inducted" onChange={(date) => setStartDate(date)} />
                                                                {/* <TextField id="date" onChange={handleChange ? handleChange : handleChange} value={ values.date_inducted ? values.date_inducted : values.date_inducted} type="date" name="date_inducted" InputLabelProps={{ shrink: true }} /> */}
                                                                <h6 style={{color:'red'}}>{Validations.date_inducted}</h6>
                                                            </div>


                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Number of Pilot Seats*</label>
                                                                <input className="form-control form-control-lg" type="text" maxLength={50} onChange={handleChange ? handleChange : handleChange} name="no_pilot_seat" value={values.no_pilot_seat ? values.no_pilot_seat : values.no_pilot_seat} placeholder="Enter the pilot seats" />
                                                                <h6 style={{color:'red'}}>{Validations.no_pilot_seat}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Number of Passenger Seat*</label>
                                                                <input className="form-control form-control-lg" type="text" maxLength={50}  onChange={handleChange ? handleChange : handleChange} name="no_of_passenger_seats" value={values.no_of_passenger_seats ? values.no_of_passenger_seats : values.no_of_passenger_seat} placeholder="Enter the pilot seats" />
                                                                <h6 style={{color:'red'}}>{Validations.no_of_passenger_seat}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Pilot*</label>
                                                                <select
                                                                   className="form-control"
                                                                    name="pilot"
                                                                    value={values.pilot ? values.pilot : values.pilot}
                                                                    tooltipFeedback
                                                                    onChange={handleChange ? handleChange : handleChange}
                                                                >
                                                                    <option selected="" disabled={true} value="">
                                                                        Choose...
                                                                    </option>
                                                                    <option value="Single Pilot">Single Pilot</option>
                                                                    <option value="Multi Crew">Multi Crew</option>
                                                                </select>
                                                                <h6 style={{color:'red'}}>{Validations.pilot}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Night Parking Base*</label>
                                                                <select
                                                                  className='form-control'
                                                                    value={values.night_parking_base ? values.night_parking_base : values.night_parking_base}
                                                                    name="night_parking_base"
                                                                    onChange={handleChange ? handleChange : handleChange}
                                                                    tooltipFeedback
                                                                >
                                                                    <option selected="" disabled>
                                                                        Choose...
                                                                    </option>
                                                                    {
                                                                        airport && airport.map((option) => {
                                                                            return (
                                                                                <option key={option.id} value={option.airport_name}>{option?.airport_name}</option>
                                                                            );
                                                                        })
                                                                    }
                                                                </select>
                                                                <h6 style={{color:'red'}}>{Validations.night_parking_base}</h6>
                                                            </div>

                                                            <div className="mb-3 text-start">
                                                                <label className="form-label">Baggage Capacity* (in Kg)</label>
                                                                <div className='position-relative'>
                                                                    <input
                                                                        type="text"
                                                                        className='form-control'
                                                                        placeholder="Please enter the baggage"
                                                                        value={values.baggage_capacity ? values.baggage_capacity : values.baggage_capacity}
                                                                        onChange={handleChange ? handleChange : handleChange}
                                                                        name="baggage_capacity" />
                                                                    
                                                                    <h6 style={{color:'red'}}>{Validations.baggage_capacity}</h6>
                                                                </div>

                                                            </div>

                                                            <div className="mb-3">

                                                                <button className="btn btn-lg btn-primary mx-2" disabled={disabledBtn} type="submit">Update</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
    )
}
