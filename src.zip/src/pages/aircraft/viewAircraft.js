import React, { useState, useEffect } from 'react'
import SideBar from '../../component/sidebar/sidebar'
import Topbar from '../../component/topbar/topbar';

import { useDispatch, useSelector } from 'react-redux';
import { BASE_IMG_URL } from '../../util/constant';
import dummy from "../../util/img/photos/dummy.png"
import { Link, useParams } from 'react-router-dom';
import { viewAircraftTaxi } from '../../component/store/aircraft/aircraftSlice';

export default function ViewAirCraft() {
  const dispatch = useDispatch();
  const [profile, setProfileDetail] = useState("")
  const { viewAircraftDetail } = useSelector((state) => state.aircraft);
const params=useParams();
  useEffect(() => {
    let payload = {
      id:(params.id)
    }
    dispatch(viewAircraftTaxi(payload))
  }, []);

  useEffect(() => {
    if (viewAircraftDetail) {
      setProfileDetail(viewAircraftDetail)
    }
  }, [viewAircraftDetail]);

console.log('____________________________________________________profile detail is her ',profile)

  return (
    <div className='wrapper'>
      <SideBar />
      <div className="main">
        <Topbar />
        <main className="d-flex w-100 employee-wrapper profile-detail card-header">
          <div className="container d-flex flex-column">
            <div className="row justify-content-center mt-5">
              <div className='col-md-9 px-0'>
                <div className='profile-info p-4'>
                <div className='row create-btn'>
                          <div className='col-lg-8 text-end'>
                                <h3 className=' fs-2'>Aircraft Information</h3>
                            </div>
                            <div className='col-lg-4 text-end'>
                              <Link to="/aircraftListing" className='btn btn-primary'>Back</Link>
                            </div>
                          </div>
                  
                 
                  <div class="card-body">
                    <div className='d-flex justify-content-between'>
                    </div>

                    {/* <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Role</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start cutom-upper-letter">
                          {
                            profile.user_role==='1' ? (<h6>Admin</h6>)
                            : profile.user_role==='2' ? (<h6>Normal User</h6>)
                            : profile.user_role==='3' ? (<h6>Employee</h6>)
                            :'Role not found'
                          }</p>
                      </div>
                    </div> */}

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Aircraft Model</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start cutom-upper-letter">{profile ? profile.aircraft_model : 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start cutom-upper-letter">Year of Manufacture</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile ? profile.year_of_manufacture : 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">MSN</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile ? profile.msn : 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Reg Mark</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile ? profile.registeration_mark : 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Date Inducted</p>
                      </div>
                      <div class="col-sm-9 py-3 ">
                        <p class="text-muted mb-0 text-start">{profile ? profile.date_inducted : 'N/A'}</p>
                      </div>
                    </div>
                  {/* {
                    profile.user_role == 1  && 

                  
                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Profile Pic</p>
                      </div>
                      <div class="col-sm-3 py-3 text-center">
                        <img src={profile.profile_pic ? BASE_IMG_URL + profile.profile_pic.toLowerCase() : dummy} alt="user_profile_pic" height={100} width={100} />
                      </div>
                    </div>
                  } */}
                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Pilot Seat</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile ? profile.no_pilot_seats : 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Passenger Seat</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile ? profile.no_of_passenger_seats
 : 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Pilot</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile ? profile.pilot : 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom" >
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Night Parking Base</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile ? profile.night_parking_base : 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Baggage Capacity</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile ? profile.baggage_capacity : 'N/A'}</p>
                      </div>
                    </div>


                    {
                profile && profile.reason && 
                    <div class="row">
                    <div class="col-sm-3 py-3">
                      <p class="mb-0 text-start">Block Reason</p>
                    </div>
                    <div class="col-sm-9 py-3">
                      <p class="text-muted mb-0 text-start">{profile && profile.reason || 'N/A'}</p>
                    </div>
                  </div>
              }

                  </div>

                </div>

              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

  )
}
