import React, { useEffect, useMemo, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import SideBar from '../../component/sidebar/sidebar'

import { getALlAirport } from '../../component/store/flight/flightSlice'

import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import TableArrow from "../../util/img/photos/table-arrow.svg"
import { Link } from 'react-router-dom';
import dummy from "../../util/img/photos/dummy.png"
import Topbar from '../../component/topbar/topbar';
import { BASE_IMG_URL } from '../../util/constant';
import { blockUnblockUser } from '../../component/store/user/userSlice';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
import SearchIcon from '../../util/img/icons/search.png'
import ToasterContainer from '../../component/toastify/ToasterContainer';
import 'bootstrap/dist/css/bootstrap.min.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';

export default function Airport() {
	const [userData, setUserData] = useState("");
	// const [status, setStatus] = useState("");
	// const [profile, setProfileDetail] = useState("")

	// const [show, setShow] = useState(false);

	// const handleClose = () => setShow(false);
	// const handleShow = () => setShow(true);


	const dispatch = useDispatch();
	const [search, setSearch] = useState("");
	
	const { allAirportDetail, isSuccess} = useSelector((state) => state.flight);

	
// 	const handleReasonSubmit = (event) => {
// event.preventDefault();
// alert('dispathc the api of this')
// 	}
	
	// const handleDelete = async (e, userId) => {
	// 	if (window.confirm("Are you sure you want to Delete this record ?")) {
	// 		e.preventDefault();
	// 		let payload = {
	// 			id: userId
	// 		}
	// 		await dispatch(deleteUser(payload))
	// 		await dispatch(getAllUserBySuperAdmin())

	// 	}
	// }

	useEffect(() => {
		dispatch(getALlAirport())
	}, [])


	useEffect(() => {
		if (isSuccess && allAirportDetail) {
			setUserData(allAirportDetail)
		}
	}, [allAirportDetail, isSuccess])

console.log('8********************************************************************?airport ids ghere ',userData)    
	// const handleStatus = (e, userId) => {
	// 	setShow(true);
	// 	return 
	// 	e.preventDefault();
	// 	let payload = { id: userId }
	// 	dispatch(blockUnblockUser(payload))
	// }

	const columns = [
		{
			dataField: "id",
			text: "Id",
			
			className: 'd-flex align-items-center',
			//headerFormatter:headerFacilityFormatter,
			formatter: (cell,row) => {
				return cell ? cell : 'N/A'
			}
		},
		{
			dataField: "airport_name",
			text: "Airport Name",
            sort: true,
			filter: textFilter({
				placeholder: 'Enter the airport name',
				className: 'user-custom-filter',
				caseSensitive: false
			}),
			formatter: (cell) => { return <>{cell ? cell : 'N/A'}</> }
		},
		// {
		// 	dataField: "country_code",
		// 	text: "Country Code",
		// 	formatter: (cell) => { return <>{cell ? cell : 'N/A'}</> }
		// },
		// {
		// 	dataField: "phone_number",
		// 	text: "Phone Number",
		// 	formatter: (cell) => { return cell ? cell : 'N/A' }
		// },
		// {
		// 	dataField: "profile_pic",
		// 	text: "Profile Picture",
		// 	formatter: (data) => {
		// 		if (data) {
		// 			return (<img src={data ? BASE_IMG_URL+data :dummy} height={80} width={80} alt={"profile_pic"} />)
		// 		} else {
		// 			return (<img src={dummy} height={80} width={80} alt={"profile_pic"} />)
		// 		}
		// 	}
		// },
		// {
		// 	dataField: "is_block",
		// 	text: "Status",
		// 	formatter: (data) => {
		// 		if (+data == 0) {
		// 			return (<span className="badge bg-success">Activated</span>)
		// 		} else if (+data == 1) {
		// 			return (<span className="badge bg-danger">Deactivated</span>)
		// 		}
		// 	}
		// },
		// {
		// 	dataField: "is_block",
		// 	text: "",
		// 	headerFormatter: () => {
		// 		return (<span>Action</span>);
		// 	},
		// 	formatter: (data, allData) => {
		// 		if (+data === 0) {
		// 			return (
		// 				<>
		// 					<Link to={`/editUser/${allData.id}`} className='btn  fs-12 action-svgIcons' >
		// 						<span className='custom-svgicons'>
		// 							<span className='svgIcon'>
		// 								<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
		// 									<path d="M3.27825 14.4C3.32325 14.4 3.36825 14.3955 3.41325 14.3887L7.19775 13.725C7.24275 13.716 7.2855 13.6957 7.317 13.662L16.8547 4.12425C16.8756 4.10343 16.8922 4.07871 16.9034 4.05149C16.9147 4.02427 16.9205 3.99509 16.9205 3.96562C16.9205 3.93616 16.9147 3.90698 16.9034 3.87976C16.8922 3.85254 16.8756 3.82782 16.8547 3.807L13.1153 0.06525C13.0725 0.0225 13.0162 0 12.9555 0C12.8947 0 12.8385 0.0225 12.7958 0.06525L3.258 9.603C3.22425 9.63675 3.204 9.67725 3.195 9.72225L2.53125 13.5067C2.50936 13.6273 2.51718 13.7513 2.55404 13.8682C2.59089 13.985 2.65566 14.0911 2.74275 14.1772C2.89125 14.3212 3.078 14.4 3.27825 14.4ZM4.79475 10.476L12.9555 2.3175L14.6047 3.96675L6.444 12.1253L4.44375 12.4785L4.79475 10.476ZM17.28 16.29H0.72C0.32175 16.29 0 16.6117 0 17.01V17.82C0 17.919 0.081 18 0.18 18H17.82C17.919 18 18 17.919 18 17.82V17.01C18 16.6117 17.6783 16.29 17.28 16.29Z" fill="#808385" />
		// 								</svg>
		// 							</span>
		// 							<span className='hover-text'>
		// 								<span className='hover-innertext'>
		// 									<span className='inner-text'>
		// 										Edit
		// 									</span>
		// 								</span>
		// 							</span>
		// 						</span>
		// 					</Link>

		// 					{/* <Link to="#" className='btn action-svgIcons fs-12' onClick={(e) => handleStatus(e, allData.id)}>
		// 						<span className='custom-svgicons block-icon'>
		// 							<span className='svgIcon'>
		// 								<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
		// 									<path d="M9 0.75C7.36831 0.75 5.77325 1.23385 4.41655 2.14038C3.05984 3.0469 2.00242 4.33537 1.378 5.84286C0.753575 7.35035 0.590197 9.00915 0.908525 10.6095C1.22685 12.2098 2.01259 13.6798 3.16637 14.8336C4.32016 15.9874 5.79017 16.7732 7.39051 17.0915C8.99085 17.4098 10.6497 17.2464 12.1571 16.622C13.6646 15.9976 14.9531 14.9402 15.8596 13.5835C16.7661 12.2268 17.25 10.6317 17.25 9C17.2474 6.81276 16.3774 4.71584 14.8308 3.16922C13.2842 1.6226 11.1872 0.75258 9 0.75ZM2.25 9C2.2494 7.46938 2.77205 5.98454 3.73125 4.79175L13.2083 14.2688C12.2164 15.0638 11.02 15.5622 9.75701 15.7065C8.49406 15.8508 7.21605 15.6351 6.07042 15.0842C4.9248 14.5334 3.95824 13.6699 3.28226 12.5934C2.60629 11.5169 2.24844 10.2712 2.25 9ZM14.2688 13.2083L4.79175 3.73125C6.08717 2.6928 7.72022 2.16888 9.37799 2.25987C11.0358 2.35087 12.6017 3.05037 13.7757 4.22435C14.9496 5.39834 15.6491 6.96424 15.7401 8.62201C15.8311 10.2798 15.3072 11.9128 14.2688 13.2083Z" fill="#808385" />
		// 								</svg>
		// 							</span>
		// 							<span className='hover-text'>
		// 								<span className='hover-innertext'>
		// 									<span className='inner-text'>
		// 										Block
		// 									</span>
		// 								</span>
		// 							</span>

		// 						</span>
		// 					</Link> */}

		// 					{/* <Link to="#" onClick={(e) => handleDelete(e, allData.id)} className='btn action-svgIcons fs-12'>
		// 						<span className='custom-svgicons delete-icon'>
		// 							<span className='svgIcon'>
		// 								<svg width="17" height="18" viewBox="0 0 17 18" fill="none" xmlns="http://www.w3.org/2000/svg">
		// 									<path d="M8.28582 6.20016e-09C9.02942 -4.83082e-05 9.74486 0.28227 10.2854 0.789041C10.8259 1.29581 11.1505 1.98862 11.1926 2.72533L11.197 2.88889H15.8998C16.07 2.88894 16.2339 2.95311 16.3583 3.06842C16.4826 3.18373 16.5583 3.3416 16.5699 3.51012C16.5815 3.67863 16.5282 3.84524 16.4208 3.97627C16.3133 4.10729 16.1598 4.19298 15.9912 4.216L15.8998 4.22222H15.1868L14.0402 15.7956C13.9828 16.3725 13.7205 16.9105 13.3003 17.3133C12.8801 17.7161 12.3292 17.9576 11.7462 17.9947L11.5885 18H4.98313C4.39861 18 3.83315 17.7937 3.38778 17.418C2.94242 17.0424 2.64619 16.5218 2.55203 15.9493L2.53143 15.7947L1.38396 4.22222H0.671823C0.509477 4.22222 0.352625 4.16387 0.230273 4.05798C0.107922 3.9521 0.0283494 3.80583 0.00627032 3.64622L0 3.55556C6.84623e-06 3.39446 0.0588003 3.23881 0.165508 3.1174C0.272215 2.99598 0.419617 2.91702 0.580455 2.89511L0.671823 2.88889H5.37458C5.37458 2.12271 5.6813 1.38791 6.22726 0.846136C6.77323 0.304364 7.51371 6.20016e-09 8.28582 6.20016e-09ZM13.8369 4.22222H2.73387L3.8688 15.664C3.89394 15.9193 4.00731 16.1581 4.18969 16.3399C4.37207 16.5217 4.61221 16.6353 4.86937 16.6613L4.98313 16.6667H11.5885C12.126 16.6667 12.5819 16.2889 12.6858 15.776L12.7037 15.664L13.8369 4.22222ZM9.8534 6.66667C10.0157 6.66667 10.1726 6.72502 10.295 6.8309C10.4173 6.93679 10.4969 7.08306 10.519 7.24267L10.5252 7.33333V13.5556C10.5252 13.7245 10.4605 13.8871 10.3443 14.0105C10.2281 14.1339 10.069 14.209 9.89919 14.2205C9.72937 14.232 9.56148 14.1791 9.42944 14.0725C9.2974 13.9659 9.21105 13.8136 9.18785 13.6462L9.18158 13.5556V7.33333C9.18158 7.15652 9.25236 6.98695 9.37835 6.86193C9.50434 6.73691 9.67523 6.66667 9.8534 6.66667ZM6.71823 6.66667C6.88058 6.66667 7.03743 6.72502 7.15978 6.8309C7.28213 6.93679 7.3617 7.08306 7.38378 7.24267L7.39005 7.33333V13.5556C7.39 13.7245 7.32534 13.8871 7.20913 14.0105C7.09293 14.1339 6.93384 14.209 6.76402 14.2205C6.5942 14.232 6.42631 14.1791 6.29427 14.0725C6.16222 13.9659 6.07588 13.8136 6.05268 13.6462L6.04641 13.5556V7.33333C6.04641 7.15652 6.11719 6.98695 6.24318 6.86193C6.36917 6.73691 6.54005 6.66667 6.71823 6.66667ZM8.28582 1.33333C7.89241 1.33335 7.51338 1.48015 7.22399 1.7446C6.93459 2.00906 6.75598 2.37182 6.7236 2.76089L6.71823 2.88889H9.8534C9.8534 2.47633 9.68825 2.08067 9.39427 1.78895C9.10029 1.49722 8.70157 1.33333 8.28582 1.33333Z" fill="#808385" />
		// 								</svg>
		// 							</span>
		// 							<span className='hover-text'>
		// 								<span className='hover-innertext'>
		// 									<span className='inner-text'>
		// 										Delete
		// 									</span>
		// 								</span>
		// 							</span>

		// 						</span>
		// 					</Link> */}

		// 					{/* <Link to={`/viewUser/${allData.id}`} className='btn action-svgIcons fs-12'>
		// 						<span className='custom-svgicons view-icon'>
		// 							<span className='svgIcon'>
		// 								<svg width="18" height="12" viewBox="0 0 18 12" fill="none" xmlns="http://www.w3.org/2000/svg">
		// 									<path d="M17.8856 5.64988C17.7248 5.42991 13.8933 0.263733 8.99989 0.263733C4.10646 0.263733 0.274848 5.42991 0.114219 5.64967C0.039997 5.75135 0 5.87399 0 5.99988C0 6.12577 0.039997 6.24841 0.114219 6.35009C0.274848 6.57006 4.10646 11.7362 8.99989 11.7362C13.8933 11.7362 17.7248 6.57003 17.8856 6.35027C17.9599 6.24863 17.9999 6.12598 17.9999 6.00007C17.9999 5.87416 17.9599 5.75152 17.8856 5.64988ZM8.99989 10.5494C5.39536 10.5494 2.27345 7.12054 1.34929 5.99958C2.27225 4.87764 5.38762 1.45054 8.99989 1.45054C12.6042 1.45054 15.726 4.87883 16.6505 6.00039C15.7275 7.1223 12.6122 10.5494 8.99989 10.5494Z" fill="#808385" />
		// 									<path d="M8.9999 2.43956C7.03671 2.43956 5.43945 4.03681 5.43945 6.00001C5.43945 7.9632 7.03671 9.56046 8.9999 9.56046C10.9631 9.56046 12.5604 7.9632 12.5604 6.00001C12.5604 4.03681 10.9631 2.43956 8.9999 2.43956ZM8.9999 8.37362C7.69104 8.37362 6.62629 7.30884 6.62629 6.00001C6.62629 4.69118 7.69107 3.6264 8.9999 3.6264C10.3087 3.6264 11.3735 4.69118 11.3735 6.00001C11.3735 7.30884 10.3088 8.37362 8.9999 8.37362Z" fill="#808385" />
		// 								</svg>
		// 							</span>
		// 							<span className='hover-text'>
		// 								<span className='hover-innertext'>
		// 									<span className='inner-text'>
		// 										View
		// 									</span>
		// 								</span>
		// 							</span>

		// 						</span>
		// 					</Link> */}
		// 				</>

		// 			)
		// 		} else if (+data === 1) {
		// 			return (
		// 				<>
		// 					{/* <Link to={`/editUser/${allData.id}`} className='btn  fs-12 action-svgIcons' >
		// 						<span className='custom-svgicons'>
		// 							<span className='svgIcon'>
		// 								<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
		// 									<path d="M3.27825 14.4C3.32325 14.4 3.36825 14.3955 3.41325 14.3887L7.19775 13.725C7.24275 13.716 7.2855 13.6957 7.317 13.662L16.8547 4.12425C16.8756 4.10343 16.8922 4.07871 16.9034 4.05149C16.9147 4.02427 16.9205 3.99509 16.9205 3.96562C16.9205 3.93616 16.9147 3.90698 16.9034 3.87976C16.8922 3.85254 16.8756 3.82782 16.8547 3.807L13.1153 0.06525C13.0725 0.0225 13.0162 0 12.9555 0C12.8947 0 12.8385 0.0225 12.7958 0.06525L3.258 9.603C3.22425 9.63675 3.204 9.67725 3.195 9.72225L2.53125 13.5067C2.50936 13.6273 2.51718 13.7513 2.55404 13.8682C2.59089 13.985 2.65566 14.0911 2.74275 14.1772C2.89125 14.3212 3.078 14.4 3.27825 14.4ZM4.79475 10.476L12.9555 2.3175L14.6047 3.96675L6.444 12.1253L4.44375 12.4785L4.79475 10.476ZM17.28 16.29H0.72C0.32175 16.29 0 16.6117 0 17.01V17.82C0 17.919 0.081 18 0.18 18H17.82C17.919 18 18 17.919 18 17.82V17.01C18 16.6117 17.6783 16.29 17.28 16.29Z" fill="#808385" />
		// 								</svg>
		// 							</span>
		// 							<span className='hover-text'>
		// 								<span className='hover-innertext'>
		// 									<span className='inner-text'>
		// 										Edit
		// 									</span>
		// 								</span>
		// 							</span>
		// 						</span>
		// 					</Link> */}

		// 					{/* <Link to="#" className='btn action-svgIcons fs-12' onClick={(e) => handleStatus(e, allData.id)}>
		// 						<span className='custom-svgicons block-icon unlock-icon'>
		// 							<span className='svgIcon'>
		// 								<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
		// 									<path d="M9 0.75C7.36831 0.75 5.77325 1.23385 4.41655 2.14038C3.05984 3.0469 2.00242 4.33537 1.378 5.84286C0.753575 7.35035 0.590197 9.00915 0.908525 10.6095C1.22685 12.2098 2.01259 13.6798 3.16637 14.8336C4.32016 15.9874 5.79017 16.7732 7.39051 17.0915C8.99085 17.4098 10.6497 17.2464 12.1571 16.622C13.6646 15.9976 14.9531 14.9402 15.8596 13.5835C16.7661 12.2268 17.25 10.6317 17.25 9C17.2474 6.81276 16.3774 4.71584 14.8308 3.16922C13.2842 1.6226 11.1872 0.75258 9 0.75ZM2.25 9C2.2494 7.46938 2.77205 5.98454 3.73125 4.79175L13.2083 14.2688C12.2164 15.0638 11.02 15.5622 9.75701 15.7065C8.49406 15.8508 7.21605 15.6351 6.07042 15.0842C4.9248 14.5334 3.95824 13.6699 3.28226 12.5934C2.60629 11.5169 2.24844 10.2712 2.25 9ZM14.2688 13.2083L4.79175 3.73125C6.08717 2.6928 7.72022 2.16888 9.37799 2.25987C11.0358 2.35087 12.6017 3.05037 13.7757 4.22435C14.9496 5.39834 15.6491 6.96424 15.7401 8.62201C15.8311 10.2798 15.3072 11.9128 14.2688 13.2083Z" fill="#808385" />
		// 								</svg>
		// 							</span>
		// 							<span className='hover-text'>
		// 								<span className='hover-innertext'>
		// 									<span className='inner-text'>
		// 										UnBlock
		// 									</span>
		// 								</span>
		// 							</span>

		// 						</span>
		// 					</Link> */}

		// 					{/* <Link to="#" onClick={(e) => handleDelete(e, allData.id)} className='btn action-svgIcons fs-12'>
		// 						<span className='custom-svgicons delete-icon'>
		// 							<span className='svgIcon'>
		// 								<svg width="17" height="18" viewBox="0 0 17 18" fill="none" xmlns="http://www.w3.org/2000/svg">
		// 									<path d="M8.28582 6.20016e-09C9.02942 -4.83082e-05 9.74486 0.28227 10.2854 0.789041C10.8259 1.29581 11.1505 1.98862 11.1926 2.72533L11.197 2.88889H15.8998C16.07 2.88894 16.2339 2.95311 16.3583 3.06842C16.4826 3.18373 16.5583 3.3416 16.5699 3.51012C16.5815 3.67863 16.5282 3.84524 16.4208 3.97627C16.3133 4.10729 16.1598 4.19298 15.9912 4.216L15.8998 4.22222H15.1868L14.0402 15.7956C13.9828 16.3725 13.7205 16.9105 13.3003 17.3133C12.8801 17.7161 12.3292 17.9576 11.7462 17.9947L11.5885 18H4.98313C4.39861 18 3.83315 17.7937 3.38778 17.418C2.94242 17.0424 2.64619 16.5218 2.55203 15.9493L2.53143 15.7947L1.38396 4.22222H0.671823C0.509477 4.22222 0.352625 4.16387 0.230273 4.05798C0.107922 3.9521 0.0283494 3.80583 0.00627032 3.64622L0 3.55556C6.84623e-06 3.39446 0.0588003 3.23881 0.165508 3.1174C0.272215 2.99598 0.419617 2.91702 0.580455 2.89511L0.671823 2.88889H5.37458C5.37458 2.12271 5.6813 1.38791 6.22726 0.846136C6.77323 0.304364 7.51371 6.20016e-09 8.28582 6.20016e-09ZM13.8369 4.22222H2.73387L3.8688 15.664C3.89394 15.9193 4.00731 16.1581 4.18969 16.3399C4.37207 16.5217 4.61221 16.6353 4.86937 16.6613L4.98313 16.6667H11.5885C12.126 16.6667 12.5819 16.2889 12.6858 15.776L12.7037 15.664L13.8369 4.22222ZM9.8534 6.66667C10.0157 6.66667 10.1726 6.72502 10.295 6.8309C10.4173 6.93679 10.4969 7.08306 10.519 7.24267L10.5252 7.33333V13.5556C10.5252 13.7245 10.4605 13.8871 10.3443 14.0105C10.2281 14.1339 10.069 14.209 9.89919 14.2205C9.72937 14.232 9.56148 14.1791 9.42944 14.0725C9.2974 13.9659 9.21105 13.8136 9.18785 13.6462L9.18158 13.5556V7.33333C9.18158 7.15652 9.25236 6.98695 9.37835 6.86193C9.50434 6.73691 9.67523 6.66667 9.8534 6.66667ZM6.71823 6.66667C6.88058 6.66667 7.03743 6.72502 7.15978 6.8309C7.28213 6.93679 7.3617 7.08306 7.38378 7.24267L7.39005 7.33333V13.5556C7.39 13.7245 7.32534 13.8871 7.20913 14.0105C7.09293 14.1339 6.93384 14.209 6.76402 14.2205C6.5942 14.232 6.42631 14.1791 6.29427 14.0725C6.16222 13.9659 6.07588 13.8136 6.05268 13.6462L6.04641 13.5556V7.33333C6.04641 7.15652 6.11719 6.98695 6.24318 6.86193C6.36917 6.73691 6.54005 6.66667 6.71823 6.66667ZM8.28582 1.33333C7.89241 1.33335 7.51338 1.48015 7.22399 1.7446C6.93459 2.00906 6.75598 2.37182 6.7236 2.76089L6.71823 2.88889H9.8534C9.8534 2.47633 9.68825 2.08067 9.39427 1.78895C9.10029 1.49722 8.70157 1.33333 8.28582 1.33333Z" fill="#808385" />
		// 								</svg>
		// 							</span>
		// 							<span className='hover-text'>
		// 								<span className='hover-innertext'>
		// 									<span className='inner-text'>
		// 										Delete
		// 									</span>
		// 								</span>
		// 							</span>

		// 						</span>
		// 					</Link> */}

		// 					{/* <Link to={`/viewUser/${allData.id}`} className='btn action-svgIcons fs-12'>
		// 						<span className='custom-svgicons view-icon'>
		// 							<span className='svgIcon'>
		// 								<svg width="18" height="12" viewBox="0 0 18 12" fill="none" xmlns="http://www.w3.org/2000/svg">
		// 									<path d="M17.8856 5.64988C17.7248 5.42991 13.8933 0.263733 8.99989 0.263733C4.10646 0.263733 0.274848 5.42991 0.114219 5.64967C0.039997 5.75135 0 5.87399 0 5.99988C0 6.12577 0.039997 6.24841 0.114219 6.35009C0.274848 6.57006 4.10646 11.7362 8.99989 11.7362C13.8933 11.7362 17.7248 6.57003 17.8856 6.35027C17.9599 6.24863 17.9999 6.12598 17.9999 6.00007C17.9999 5.87416 17.9599 5.75152 17.8856 5.64988ZM8.99989 10.5494C5.39536 10.5494 2.27345 7.12054 1.34929 5.99958C2.27225 4.87764 5.38762 1.45054 8.99989 1.45054C12.6042 1.45054 15.726 4.87883 16.6505 6.00039C15.7275 7.1223 12.6122 10.5494 8.99989 10.5494Z" fill="#808385" />
		// 									<path d="M8.9999 2.43956C7.03671 2.43956 5.43945 4.03681 5.43945 6.00001C5.43945 7.9632 7.03671 9.56046 8.9999 9.56046C10.9631 9.56046 12.5604 7.9632 12.5604 6.00001C12.5604 4.03681 10.9631 2.43956 8.9999 2.43956ZM8.9999 8.37362C7.69104 8.37362 6.62629 7.30884 6.62629 6.00001C6.62629 4.69118 7.69107 3.6264 8.9999 3.6264C10.3087 3.6264 11.3735 4.69118 11.3735 6.00001C11.3735 7.30884 10.3088 8.37362 8.9999 8.37362Z" fill="#808385" />
		// 								</svg>
		// 							</span>
		// 							<span className='hover-text'>
		// 								<span className='hover-innertext'>
		// 									<span className='inner-text'>
		// 										View
		// 									</span>
		// 								</span>
		// 							</span>

		// 						</span>
		// 					</Link> */}
		// 				</>
		// 			)
		// 		}
		// 	}
		// }
	];

	return (
		<div>
			<ToasterContainer/>
			<div className='wrapper'>
				<SideBar />
				<div className='main'>
					<Topbar />
					<div className="d-flex w-100 employee-wrapper custom-employe-table custom-user-table user-wrap flight-wrapper">
						<div className='container'>
							<div className="row">
								<div className="col-md-12 d-flex px-0">

									<div className="card flex-fill">
										<div className="card-header d-flex justify-content-between align-items-center">

											<h5 className="card-title mb-0">Latest Airport</h5>
											<img src={SearchIcon} alt={"search-icon"} height={50} width={50} className="custom-searchemployee-icon" />
											{/* <input type="search" name="search" value={search} placeholder="Enter the key" onChange={(e) => setSearch(e.target.value)} /> */}
											{/* <div className='text-right create-btn'><Link to="/createUser" className='btn btn-primary'>Create User</Link></div> */}

										</div>
										<BootstrapTable keyField='id' filter={filterFactory()} data={userData && userData} noDataIndication={() => { return 'No Data Found' }} columns={columns} bordered={false} pagination={userData && paginationFactory(
											{ 
											sizePerPage: 10,
											page:1,
											lastPageText:'>>',
											firstPageText:'<<',
											showTotal:true,
											//alwaysShowAllBtns:true,
											//totalSize:100,
											sizePerPageList:[ 
												{
												text: '10', value: 10
											  }, {
												text: '20', value: 20
											  },
											  {
												text: '30', value: 30
											  },
											  {
												text: 'All', value: userData.length
											  } ],
											//nextPageText:'Next',
											//prePageText:'Prev',
											onPageChange:function (page, sizePerPage) {
												console.log('page',page);
												console.log('page',sizePerPage);
											},
											onSizePerPageChange:function(page, sizePerPage){
												console.log('page',page);
												console.log('sizeperpage',sizePerPage)
											} 
											}
											)} />
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	)
}
