import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import SideBar from '../../component/sidebar/sidebar'
import { getAllUserBySuperAdmin } from '../../component/store/user/userSlice'
import Topbar from '../../component/topbar/topbar'
import { getDashboardResult } from '../../component/store/dashboard/dashboardSlice'
import { Link } from 'react-router-dom'

export default function Dashboard() {

	const {dashboardResult,isSuccess}=useSelector((state) => state.dashboard);
	const [dashboard,setdashboard]=useState("")
	const dispatch=useDispatch();

	useEffect(() => {
		dispatch(getDashboardResult())
	},[]);

	useEffect(() => {
		if(getDashboardResult && isSuccess==true) {
			setdashboard(dashboardResult)
		}
	},[getDashboardResult, isSuccess])

  return (
    <div>
        <div className="wrapper">
		<SideBar/>
		<div className="main">
			<Topbar/>

			<main className="content">
				<div className="container-fluid p-0">

					<h1 className="h3 mb-3"><strong>Air Taxi</strong> Dashboard</h1>

					<div className="row dashboard-card">
						<div className='col-xl-4 col-md-6 col-12'>
						<Link to="/user">
										<div className="card">
											<div className="card-body">
												<div className="row">
													<div className="col mt-0">
														<h5 className="card-title">Total User</h5>
													</div>
{/* 
													<div className="col-auto">
														<div className="stat text-primary">
															<i className="align-middle" data-feather="truck"></i>
														</div>
													</div> */}
												</div>
												<h1 className="mt-1 mb-3">{dashboard.user || ''}</h1>
												<div className="mb-0">
												</div>
											</div>
										</div>
										</Link>
						</div>
						<div className='col-xl-4 col-md-6 col-12'>
						<Link to="/flightListing">
										<div className="card">
											<div className="card-body">
												<div className="row">
													<div className="col mt-0">
														<h5 className="card-title">Total Flights</h5>
													</div>

													{/* <div className="col-auto">
														<div className="stat text-primary">
															<i className="align-middle" data-feather="users"></i>
														</div>
													</div> */}
												</div>
												<h1 className="mt-1 mb-3">{dashboard.flight || '0'}</h1>
												<div className="mb-0">
												</div>
											</div>
										</div>
										</Link>
						</div>
						<div className='col-xl-4 col-md-6 col-12'>
						<Link to="/employee">
										<div className="card">
											<div className="card-body">
												<div className="row">
													<div className="col mt-0">
														<h5 className="card-title">Total Employee</h5>
													</div>

													{/* <div className="col-auto">
														<div className="stat text-primary">
															<i className="align-middle" data-feather="dollar-sign"></i>
														</div>
													</div> */}
												</div>
												<h1 className="mt-1 mb-3">{dashboard.employee || ''}</h1>
												<div className="mb-0">
												</div>
											</div>
										</div>
										</Link>

						</div>
						<div className='col-xl-4 col-md-6 col-12'>
						<Link to="/aircraftListing">
										<div className="card">
											<div className="card-body">
												<div className="row">
													<div className="col mt-0">
														<h5 className="card-title">Total Aircraft</h5>
													</div>

													{/* <div className="col-auto">
														<div className="stat text-primary">
															<i className="align-middle" data-feather="shopping-cart"></i>
														</div>
													</div> */}
												</div>
												<h1 className="mt-1 mb-3">{dashboard.seat || '0'}</h1>
												<div className="mb-0">
												</div>
											</div>
										</div>
										</Link>

						</div>
						{/* <div className="col-xl-6 col-xxl-5 d-flex">
							<div className="w-100">
								<div className="row dashboard-card">
									<div className="col-sm-6">
										
										
									</div>
									<div className="col-sm-6">
										
										
									</div>
								</div>
							</div>
						</div> */}

						<div className='col-xl-4 col-md-6 col-12'>
						<Link to="/airport">
										<div className="card">
											<div className="card-body">
												<div className="row">
													<div className="col mt-0">
														<h5 className="card-title">Total Airport</h5>
													</div>

													{/* <div className="col-auto">
														<div className="stat text-primary">
															<i className="align-middle" data-feather="shopping-cart"></i>
														</div>
													</div> */}
												</div>
												<h1 className="mt-1 mb-3">{dashboard.airport || '0'}</h1>
												<div className="mb-0">
												</div>
											</div>
										</div>
										</Link>
						</div>
						<div className='col-xl-4 col-md-6 col-12'>
						<Link to="#">
										<div className="card">
											<div className="card-body">
												<div className="row">
													<div className="col mt-0">
														<h5 className="card-title">Total Payment</h5>
													</div>

													{/* <div className="col-auto">
														<div className="stat text-primary">
															<i className="align-middle" data-feather="shopping-cart"></i>
														</div>
													</div> */}
												</div>
												<h1 className="mt-1 mb-3">{dashboard.payment || '0'}</h1>
												<div className="mb-0">
												</div>
											</div>
										</div>
										</Link>

						</div>
					</div>

					
				</div>
			</main>

			<footer className="footer">
				<div className="container-fluid">
					<div className="row text-muted">
						<div className="col-6 text-start">
							<p className="mb-0">
								<a className="text-muted" href="/airtaxi" target="_blank"><strong>Air Taxi</strong></a> &copy;
							</p>
						</div>
						{/* <div className="col-6 text-end">
							<ul className="list-inline">
								<li className="list-inline-item">
									<a className="text-muted" href="https://adminkit.io/" target="_blank">Support</a>
								</li>
								<li className="list-inline-item">
									<a className="text-muted" href="https://adminkit.io/" target="_blank">Help Center</a>
								</li>
								<li className="list-inline-item">
									<a className="text-muted" href="https://adminkit.io/" target="_blank">Privacy</a>
								</li>
								<li className="list-inline-item">
									<a className="text-muted" href="https://adminkit.io/" target="_blank">Terms</a>
								</li>
							</ul>
						</div> */}
					</div>
				</div>
			</footer>
		</div>
	</div>
    </div>
  )
}
