import React, { useState, useEffect } from 'react'
import SideBar from '../../component/sidebar/sidebar'
import Topbar from '../../component/topbar/topbar';

import { useDispatch, useSelector } from 'react-redux';
import { Link, useParams } from 'react-router-dom';
import { viewEmpDetail } from '../../component/store/employee/employeeSlice';
import { BASE_IMG_URL } from '../../util/constant';
import dummy from "../../util/img/photos/dummy.png"
export default function ViewUser() {
    const {viewEmployeeDetail} =useSelector((state) => state.employee)
    const [view,setVeiwState]=useState("")


  const dispatch=useDispatch();
  const [profile,setProfileDetail]=useState("")
  const [singleEmp,setSingleEmp]=useState("")
  const params=useParams();
  const empId=params.id


    useEffect(() =>  {
      console.log('emp id is here',empId)
        dispatch(viewEmpDetail(empId))
    },[]);

    useEffect(() => {
        if(viewEmployeeDetail) {
            setProfileDetail(viewEmployeeDetail)
        }
    },[viewEmployeeDetail])
    console.log('profile is here=============================',profile)
  return (
    <div className='wrapper'>
	   <SideBar/>
	   <div className="main">
	   <Topbar/>
	   <main className="d-flex w-100 employee-wrapper profile-detail card-header">
            <div className="container d-flex flex-column">
                <div className="row justify-content-center mt-5 ">
                    <div className='col-md-9 px-0'>
                        <div className='profile-info p-4'>
                          <div className='row create-btn'>
                          <div className='col-lg-8 text-end'>
                                <h3 className=' fs-2'>View Employee</h3>
                            </div>
                            <div className='col-lg-4 text-end'>
                              <Link to="/employee" className='btn btn-primary'>Back</Link>
                            </div>
                          </div>
                           
                        <div class="card-body">
                          
              <div class="row border-bottom">
                <div class="col-sm-3 py-3">
                  <p class="mb-0 text-start">First Name</p>
                </div>
                <div class="col-sm-9 py-3">
                  <p class="text-muted mb-0 text-start">{ profile.first_name || 'N/A' }</p>
                </div>
              </div>

              <div class="row border-bottom">
                <div class="col-sm-3 py-3">
                  <p class="mb-0 text-start">Last Name</p>
                </div>
                <div class="col-sm-9 py-3">
                  <p class="text-muted mb-0 text-start">{ profile.last_name || 'N/A' }</p>
                </div>
              </div>
              
              <div class="row border-bottom">
                <div class="col-sm-3 py-3">
                  <p class="mb-0 text-start">Email</p>
                </div>
                <div class="col-sm-9 py-3">
                  <p class="text-muted mb-0 text-start">{profile && profile.email || 'N/A'}</p>
                </div>
              </div>
              
              <div class="row border-bottom">
                <div class="col-sm-3 py-3">
                  <p class="mb-0 text-start">Country Code</p>
                </div>
                <div class="col-sm-9 py-3">
                  <p class="text-muted mb-0 text-start">{profile && profile.country_code || 'N/A'}</p>
                </div>
              </div>
              
              <div class="row border-bottom">
                <div class="col-sm-3 py-3">
                  <p class="mb-0 text-start">Mobile</p>
                </div>
                <div class="col-sm-9 py-3">
                  <p class="text-muted mb-0 text-start">{profile && profile.phone_number || 'N/A'}</p>
                </div>
              </div>

              {/* <div class="row border-bottom">
                <div class="col-sm-3 py-3">
                  <p class="mb-0 text-start">Profile Pic</p>
                </div>
              <div class="col-sm-3 py-3">
              <img src={profile.profile_pic ? BASE_IMG_URL+profile.profile_pic.toLowerCase() : dummy}  alt="user_profile_pic" height={100} width={100} />
                </div>
              </div> */}
           
              <div class="row">
                <div class="col-sm-3 py-3">
                  <p class="mb-0 text-start">Location</p>
                </div>
                <div class="col-sm-9 py-3">
                  <p class="text-muted mb-0 text-start">{profile && profile.location || 'N/A'}</p>
                </div>
              </div>

              {
                profile && profile.reason && 
                    <div class="row">
                    <div class="col-sm-3 py-3">
                      <p class="mb-0 text-start">Block Reason</p>
                    </div>
                    <div class="col-sm-9 py-3">
                      <p class="text-muted mb-0 text-start">{profile && profile.reason || 'N/A'}</p>
                    </div>
                  </div>
              }
              
            </div>

                        </div>

                    </div>
                </div>
            </div>
        </main>
        </div>
    </div>
            
  )
}
