import React, { useEffect, useRef, useState } from 'react'
import { toast, ToastContainer } from 'react-toastify'
import SideBar from '../../component/sidebar/sidebar'
import Topbar from '../../component/topbar/topbar.js'
import Footer from '../../component/footer.js'
import { useDispatch, useSelector } from 'react-redux'
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import ListItemText from '@mui/material/ListItemText';
// import Select, { SelectChangeEvent } from '@mui/material/Select';
import Checkbox from '@mui/material/Checkbox';
import Select from 'react-select'
import makeAnimated from 'react-select/animated';

import { getALlAirport, getALlAircraft, getAllweekendDays, createAirTaxiFlight } from '../../component/store/flight/flightSlice'
import { findAllByAltText } from '@testing-library/react'
import { Link, useNavigate } from 'react-router-dom'
import ToasterContainer from '../../component/toastify/ToasterContainer'
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import DatePicker from "react-datepicker";
import moment from "moment"

import "react-datepicker/dist/react-datepicker.css";

export default function CreateFlight() {
	const [fromAirport, setFromAirport] = useState("")
	const [toAirport, toSetAirport] = useState("")
	const [fieldAircraft, setAircraftMode] = useState("")
	const [dayOpration, setDayOperation] = useState("")
	const [airport, setAirport] = useState("")
	const [newAirport, setNewAirport] = useState("")
	const [newAirport1, setNewAirport1] = useState("")
	const [aircraft, setAirCraft] = useState("")
	const [days, setDays] = useState("")
	const [fromValue,setFromValue]=useState("")
	const [loader,setLoader]=useState(false);
	const [airportValue, setAirportValue] = useState("Select the Airport")
	const [disabledBtn,setDisabledBtn]=useState(false);
	const [startDate, setStartDate] = useState(new Date());
	const [startDate1, setStartDate1] = useState(new Date());

	const animatedComponents = makeAnimated();

	const dispatch = useDispatch();
	const navigate = useNavigate();
	const [values, setValue] = useState({ flight_number: "", from: "", to: "", departure_date: "", departure_time: "", aircraft_model: "", days_of_operation: "",max_price:"",arrived_date:"",arrived_time:"" });
	const [Validations, setValidations] = useState({ flight_number: "", from: "", to: "", departure_date: "", departure_time: "", aircraft_model: "", days_of_operation: "",max_price:"", arrived_date:"",arrived_time:"" });

	const { allAirportDetail, isSuccess, isCreator,allAirCraftDetail, getAllDaysDetail, createFlightDetail ,message:resMessage ,autoPopulateDetail} = useSelector((state) => state.flight);

	const previousProps = useRef({ isCreator }).current;

	useEffect(() => {

		if (previousProps?.isCreator !== isCreator) {
			
			if (isCreator) {
				setTimeout(() => {
					navigate("/flightListing")
				}, 1000);
			} else if (!isCreator && resMessage) {
				toast.error("something went wrong")
			}		
		}
		return () => {
			previousProps.isCreator = isCreator;
		  };

	}, [isCreator, resMessage])

	useEffect(() => {
		dispatch(getALlAirport())
		dispatch(getALlAircraft())
		dispatch(getAllweekendDays())
	}, [])



	useEffect(() => {
		if (autoPopulateDetail && airport) {
			let to = null
			let from = null
			from = airport.find(e => e?.id == autoPopulateDetail?.from)
			to = airport.find(e => e?.id == autoPopulateDetail?.to)

			from && setAirportValue(from?.id)
			console.log(to, "tooooo");
			to && setNewAirport1(to?.id)
		}
	}, [autoPopulateDetail, airport])

	useEffect(() => {
		if (isSuccess && allAirCraftDetail) {
			setAirCraft(allAirCraftDetail)
		}

		if (getAllDaysDetail && isSuccess) {
			setDays(getAllDaysDetail)
		}
	}, [allAirCraftDetail, isSuccess, getAllDaysDetail])


	useEffect(() => {
		if (isSuccess && allAirportDetail) {
			setAirport(allAirportDetail)
			setNewAirport(allAirportDetail)

		}
	}, [isSuccess, allAirportDetail])

	const handleToAirport = async (e) => {
		const value = e.target.value
		setAirportValue(value)
		console.log(value, "valuevaluevalue");
		setFromValue(e.target.value)
		const filterdata = await airport.filter((e2) => {
			console.log(e2, "------value", value);
			return e2?.id != value
		})
		setNewAirport(filterdata)
	}

	const handleCustomDay = async (event) => {
		const id = await event.map((element) => { return element.id })
		setDayOperation(id)
	}
	const validateAll = () => {

		let isValid = true;
		const Validations = {};

		if(!values.flight_number) {
			Validations.flight_number="Please enter the flight number"
			isValid=false
		}

		if(!fromValue) {
			Validations.from="Please select the airport"
			isValid=false
		}
		if(!newAirport1) {
			Validations.to="Please select the airport"
			isValid=false
		}
		if(!fieldAircraft) {
			Validations.aircraft_model="Please select aircraft model"
			isValid=false
		}
		if(!startDate) {
			Validations.departure_date="Please select the departure date"
			isValid=false
		}
		if(!startDate1) {
			Validations.arrival_date="Please select the arrival date"
			isValid=false
		}
		if(!values.max_price) {
			Validations.max_price="Please enter the price"
			isValid=false
		}
		if(!values.departure_time) {
			Validations.departure_time="Please select the departure time"
			isValid=false
		}
		if(!values.arrived_time) {
			Validations.arrived_time="Please select the arrival time"
			isValid=false
		}
		if(!values.max_price.match(/^[0-9]{0,2}$/) && !values.max_price.match(/^\d+(?:\.\d+)?$/)){
        	Validations.max_price='Please enter the valid price'
        	isValid=false
        }
		
		if(!startDate) {
			Validations.departure_time="Please select the departure time"
			isValid=false
		}
		if(!dayOpration) {
			Validations.days_of_operation='Please select the day operation'
			isValid=false
		}
	
		if(values.email && !/\S+@\S+\.\S+/.test(values.email)) {
			Validations.email='Please enter the valid email address'
			isValid=false
		}

		if (!isValid) {
			setValidations(Validations)
		}
		return isValid;
	}

	const handleChange = (e) => {
		const { name, value } = e.target;
		setValue({ ...values, [name]: value })
	}

	const handleSubmit = async (event) => {
		event.preventDefault();

		const isValid = validateAll();
		if (!isValid) { return false; }
		setLoader(true)
		setDisabledBtn(true)
		
		const flightPayload = {
			flight_number: values.flight_number,
			from: fromValue,
			to: newAirport1,
			departure_date: moment(startDate).format("YYYY-MM-DD"),
			departure_time: values.departure_time,
			aircraft_model: fieldAircraft,
			days_of_operation: dayOpration,
			max_price:values.max_price,
			arrived_date:moment(startDate1).format("YYYY-MM-DD"),
			arrived_time:values.arrived_time
			// seatnumber: values.seatnumber
		}
		
		await dispatch(createAirTaxiFlight(flightPayload))
		//empty values set after submittion
		setValue({ flight_number: "", from: "", to: "", departure_date: "", departure_time: "", days_of_operation: "",max_price:"",arrived_time:"",arrival_date:"" })
		setAircraftMode("");
		setFromValue("")
		setNewAirport1("")

		caches.keys().then((names) => {
			// Delete all the cache files
			names.forEach(name => {
				caches.delete(name);
			})
		});
	}
	const validateOne = (e) => {
		const { name } = e.target
		const value = values[name]
		let message = ''

		if (!value && name === 'flight_number') {
			message = `Please enter the flight number`
		}

		
		if (!fromValue && name=='from') {
			message = `Please select the airport`
		}
		if (!newAirport1 && name=='to') {
			message = `Please select the airport`
		}

		if (!value && name === 'departure_date') {
			message = `Please enter select the departure date`
		}
		if (!value && name === 'departure_time') {
			message = `Please select the departure time`
		}

		if (!value && name === 'max_price') {
			message = `Please enter the max price`
		}
		
		if (!fieldAircraft && name=='aircraft_model') {
			message = `Please select the aircraft model`
		}
		// if (!dayOpration) {
		// 	message = 'Please select the days of operation'
		// }
		setValidations({ ...Validations, [name]: message })
	}


	return (
		<div>
			<ToasterContainer />
			<div className='wrapper'>
				<SideBar />
				<div className="main">
					<Topbar />
					<main class="d-flex w-100">
						<div class="container d-flex flex-column">
							<div class="row">
								<div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
									<div class="d-table-cell align-middle">

										<div class="text-center mt-4">

											<h1 class="h2">Create Flight</h1>
										</div>
										<Link to="/flightListing" class="close-FLIGHT" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">X</span>
        </Link>
										
										<div class="card">
											<div class="card-body">
												<div class="m-sm-4">
												
													<form onSubmit={(event) => handleSubmit(event)}>
														<div className="mb-3">
															<label className="form-label">Flight Number*</label>
															<input className="form-control form-control-lg" type="text" maxLength={40} onBlur={validateOne} onChange={handleChange} name="flight_number" value={values.flight_number} placeholder="Enter your flight number" />

														</div>
														<h6 style={{ color: 'red' }}>{Validations.flight_number}</h6>
														<div className="mb-3">
															<label className="form-label">From*</label>
															<select className='form-control' name='from' onBlur={validateOne} value={fromValue} onChange={(e) => handleToAirport(e)}>
																<option value="" disabled={true} selected >Choose the Airport</option>
																{
																	airport && airport.map((option) => {
																		return (
																			<option key={option.id} value={option.id}>{option?.airport_name}</option>
																		);
																	})
																}

															</select>
															<h6 style={{ color: 'red' }}>{Validations.from}</h6>
														</div>


														<div className="mb-3">
															<label className="form-label">To*</label>
															<select className='form-control' name='to' onBlur={validateOne} value={newAirport1} onChange={(e) => setNewAirport1(e.target.value)}>
																<option value="" selected disabled>Choose the Airport</option>
																{
																	newAirport && newAirport.map((option) => {
																		return (
																			<option key={option.id} value={option.id}>{option?.airport_name}</option>
																		);
																	})
																}
															</select>
														</div>
														<h6 style={{ color: 'red' }}>{Validations.to ? Validations.to : ''}</h6>
														{
															loader && 
															<div style={{ marginLeft: "180px" }}>
																<Box sx={{ display: 'flex' }}><CircularProgress /></Box>
															</div>
														}


														<div className="mb-3">
														<label className="form-label">Schdule Start Date*</label>
														<DatePicker selected={startDate} onKeyDown={(e) => {e.preventDefault(); }} className="form-control"  name="departure_date" onChange={(date) => setStartDate(date)} />	
															<h6 style={{ color: 'red' }}>{Validations.departure_date}</h6>
														</div>

														<div className="mb-3">
														<label className="form-label">Schedule Start Time*</label><br/>
															<TextField type="time"  onBlur={validateOne} onChange={handleChange} name="departure_time" value={values.departure_time} className="custom-time" InputLabelProps={{ shrink: true }} />
															<h6 style={{ color: 'red' }}>{Validations.departure_time}</h6>
														</div>


														<div className="mb-3">
														<label className="form-label">Schedule End Date*</label>
														<DatePicker selected={startDate1} onKeyDown={(e) => {e.preventDefault(); }} className="form-control"  name="arrived_date" onChange={(date) => setStartDate1(date)} />	
															<h6 style={{ color: 'red' }}>{Validations.arrived_date}</h6>
														</div>

														<div className="mb-3">
														<label className="form-label">Schedule End Time*</label><br/>
															<TextField type="time"  onBlur={validateOne} onChange={handleChange} name="arrived_time" value={values.arrived_time} className="custom-time" InputLabelProps={{ shrink: true }} />
															<h6 style={{ color: 'red' }}>{Validations.arrived_time}</h6>
														</div>

														<div className="mb-3">
															<TextField type="text" label="Price*" onBlur={validateOne} onChange={handleChange} name="max_price" value={values.max_price} className="custom-time" InputLabelProps={{ shrink: true }} placeholder="Enter the price" />
															<h6 style={{ color: 'red' }}>{Validations.max_price}</h6>
														</div>

														<div className="mb-3">
															<label className="form-label">Aircraft Model*</label>
															<select name="aircraft_model" className='form-control'  onBlur={validateOne} value={fieldAircraft}  onChange={(e) => setAircraftMode(e.target.value)}>
																<option value="" disabled selected>Choose the Aircraft Model</option>
																{
																	
																	aircraft && aircraft.map((option) => {
																		return (
																			<option key={option.id} value={option.aircraft_model}>{option?.aircraft_model}</option>
																		);
																	})
																}
															</select>
															<h6 style={{ color: 'red' }}>{Validations.aircraft_model}</h6>
														</div>

														<div className="mb-3">
															<label className="form-label">Days Operations*</label>

															<Select
																closeMenuOnSelect={false}
																components={animatedComponents}
																defaultValue={days}
																isMulti
																name="days_of_operation"
																options={days}
																onBlur={validateOne}
																onChange={event => handleCustomDay(event)}
															/>
														</div>

														<h6 style={{ color: 'red' }}>{Validations.days_of_operation}</h6>

														<div className="mb-3">
															<label className="form-label">Seats*</label>
															<input type="text" className='form-control' name="seatnumber" value={4} readOnly placeholder='Enter the Seat' />
														</div>

														<div className="text-center mt-3">
															<button type="submit" disabled={disabledBtn} className="btn btn-lg btn-primary mx-2">Submit</button>
														</div>
													</form>
												</div>
											</div>
										</div>

									</div>
								</div>
							</div>
						</div>
					</main>
					<Footer />
				</div>
			</div>
		</div>
	)
}
