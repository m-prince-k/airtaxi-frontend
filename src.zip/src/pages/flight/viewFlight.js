import React, { useState, useEffect } from 'react'
import SideBar from '../../component/sidebar/sidebar'
import Topbar from '../../component/topbar/topbar';
import dummy from "../../util/img/photos/dummy.png"
import { useDispatch, useSelector } from 'react-redux';
import { Link, useParams } from 'react-router-dom';
import { viewDetail } from '../../component/store/user/userSlice';
import { BASE_IMG_URL } from '../../util/constant';
import BootstrapTable from 'react-bootstrap-table-next';

import Button from 'react-bootstrap/Button';
import paginationFactory from 'react-bootstrap-table2-paginator';

import Modal from 'react-bootstrap/Modal';
import moment from 'moment';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
import { viewFlightAirTaxi, sheduleFlightViewListing, singleBookedFlightBid } from '../../component/store/flight/flightSlice';

const capitalizeWords = (str) => {return str.toLowerCase().split(' ').map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');};
export default function ViewUser() {
  const { viewFlightDetail, message, isSuccess, viewScheduleDetail, isViewSchedule,isSingleBid, isSingleBlockBidDetail } = useSelector((state) => state.flight)

  const dispatch = useDispatch();
  const [flightDetail, setFlightDetail] = useState("");
  const [bidDetail,setBidDetail]=useState("")
  const [viewFlight, setViewFlight] = useState("")
  const [smShow1, setSmShow1] = useState(false);
  const [singleEmp, setSingleEmp] = useState("")
  const [userData, setUserData] = useState("");
  const params = useParams();
  const [lgShow, setLgShow] = useState(false);
	const [lgShow1, setLgShow1] = useState(false);
  const userId = params.id

  useEffect(() => {
		if (isSingleBid && isSingleBlockBidDetail.message == "single booked fetched successfully") {
			setFlightDetail(isSingleBlockBidDetail.data)
		} else if(isSingleBid && isSingleBlockBidDetail.message=="single bid fetched successfully"){
			setBidDetail(isSingleBlockBidDetail.data)
		}
	}, [isSingleBlockBidDetail,isSingleBid])

  useEffect(() => {
    if (viewScheduleDetail && isViewSchedule) {
      setUserData(viewScheduleDetail)
    }
  }, [viewScheduleDetail, isViewSchedule])

  useEffect(() => {
    dispatch(viewFlightAirTaxi(userId))
    let payload = {
      parent_id: userId
    }
    dispatch(sheduleFlightViewListing(payload))
  }, []);


  const handleModalChange = (flightId) => {
		//green case run while is_booked==1
		setLgShow(true) 
		let bookedPayload = {
			flight_id: flightId,
			type: "booked"
		}
		dispatch(singleBookedFlightBid(bookedPayload))
	}

  const handleBidChange = (seatId) => {
		setSmShow1(true)
   
		let bigPayload = {
			seat_id: seatId,
			type: "bid"
		}
		dispatch(singleBookedFlightBid(bigPayload))
	}

  const columns = [
    {
      dataField: "flight_number",
      text: "Flight Number",
      className: 'd-flex align-items-center',
      //headerFormatter:headerFacilityFormatter,
      formatter: (cell) => {
        return cell ? cell : 'N/A'
      }
    },
    {
      dataField: "from",
      text: "From",
      formatter: (cell, row) => {
        // const airport_name = row?.from_airport?.airport_name ? row?.from_airport?.airport_name : 'N/A'
        // const region_name=row?.from_airport?.region_name ? row?.from_airport?.region_name: 'N/A'
        return <>{row?.from_airport?.region_name ? row?.from_airport?.region_name : 'N/A'} {row?.from_airport?.airport_name ? row?.from_airport?.airport_name : 'N/A'}</>
      }
    },
    {
      dataField: "to",
      text: "To",
      formatter: (cell, row) => {
        return <>{row?.to_airport?.airport_name ? row?.from_airport?.region_name + "-" + row?.to_airport?.airport_name : 'N/A'}</>
      }
    },
    {
      dataField: "departure_date",
      text: "Start Date",
      sort: true,
      filter: textFilter({
        placeholder: 'Enter the start date',
        className: 'view-custom-filter ',
        caseSensitive: false
      }),
      formatter: (cell, row) => {
        return cell ? cell : 'N/A'
      }
    },
    {
      dataField: "departure_time",
      text: "Start Time",
    },
    {
      dataField: "arrived_date",
      text: "End Date",
    },
    {
      dataField: "arrived_time",
      text: "End Time",
    },
    {
      dataField: "aircraft_model",
      text: "Aircraft Model",
      formatter: (cell) => {
        return cell ? cell : 'N/A'
      }
    },
    {
      dataField: "max_price",
      text: "Price",
      formatter: (cell) => {
        return cell ? cell : 'N/A'
      }
    },

    {
      dataField: "createdAt",
      text: "Seats",
      formatter: (data, row) => {

        let value = "N/A";
        if (row.FlightSeats.length) {
          value = row.FlightSeats.map((x, index) => {
            return (<>
              {x.is_booked == 1 ?
                <><button 
                  onClick={() => handleModalChange(row.id)} 
                  style={{ backgroundColor: 'green', padding: '4px', color: 'fff', marginRight: '10%', borderRadius: '0px', border: '1px solid #000000', width: '40%' }}>{x.seat}</button></> :
                x.is_bid == 1 ?
                  <><button 
                    onClick={() => handleBidChange(x.seat)} 
                    style={{ backgroundColor: 'gray', padding: '4px', color: '#000', textAlign: 'center', borderRadius: '0px', border: '1px solid #000000', width: '40%' }}>{x.seat}</button></>
                  : <><a href="#"  style={{ backgroundColor: '#FFFDD0', padding: '4px', color: '#333', borderRadius: '20px' }}>{x.seat}</a></>
              }
              {/* <Link className={`${row.is_booked ? "bg-success text-white" : row.is_bid? "bg-secondary text-white" : ''} p-1 bg-custom-grey`} to="#" >{x.seat}</Link> */}
            </>
            );
          })
        }
        return <div className={`d-flex aline-items-center flex-wrap justify-content-around view-set-button`}>{value}</div>
      }
    },
    // {
    // 	dataField: "days",
    // 	text: "Days Operation",
    // 	//formatExtraData:day,
    // 	formatter: (data, row) => {
    // 		let value = "N/A";
    // 		if (row.DayOperations.length) {
    // 			value = row.DayOperations.map(x => {
    // 				return (<>{x.Day.value}<br /></>);
    // 			})
    // 		}
    // 		return value
    // 	}
    // },
    // {
    // 	dataField: "status",
    // 	text: "Status",
    // 	formatter: (data) => {
    // 		if (+data == 0) {
    // 			return (<span className="badge bg-success">Activated</span>)
    // 		} else if (+data == 1) {
    // 			return (<span className="badge bg-danger">Deactivated</span>)
    // 		}
    // 	}
    // },
    // {
    // 	dataField: "status",
    // 	text: "",
    // 	headerFormatter: () => {
    // 		return (<span>Action</span>);
    // 	},
    // 	formatter: (data, allData) => {

    // 	}
    // }
  ];


  useEffect(() => {
    if (viewFlightDetail) {
      setViewFlight(viewFlightDetail)
    }
  }, [viewFlightDetail])

  return (
    <div className='wrapper'>
      <SideBar />
      <div className="main">
        <Topbar />
        <main className="d-flex w-100 employee-wrapper view-flight_wrapper profile-detail card-header">
          <div className="container d-flex flex-column">
            <div className="row justify-content-center mt-5">
              <div className='col-md-9 px-0'>
                <div className='profile-info p-4'>
                  <div className='row create-btn'>
                    <div className='col-lg-8 text-end'>
                      <h3 className=' fs-2'>View Flight</h3>
                    </div>
                    <div className='col-lg-4 text-end'>
                      <Link to="/flightListing" className='btn btn-primary'>Back</Link>
                    </div>
                  </div>

                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">Flight Number</p>
                      </div>
                      <div class="col-sm-9">
                        <p class="text-muted mb-0 text-start">{viewFlight && viewFlight.flight_number || 'N/A'}</p>
                      </div>
                    </div>
                  </div>


                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">From</p>
                      </div>
                      <div class="col-sm-9">
                        <p class="text-muted mb-0 text-start">{viewFlight && viewFlight?.from_airport?.region_name ? viewFlight?.from_airport?.region_name : 'N/A'} {viewFlight?.from_airport?.airport_name || 'N/A'}</p>
                      </div>
                    </div>
                  </div>

                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">To</p>
                      </div>
                      <div class="col-sm-9 ">
                        <p class="text-muted mb-0 text-start">{viewFlight && viewFlight?.from_airport?.region_name ? viewFlight?.from_airport?.region_name : 'N/A'} {viewFlight?.to_airport?.airport_name || 'N/A'}</p>
                      </div>
                    </div>
                  </div>

                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">Aircraft Model</p>
                      </div>
                      <div class="col-sm-9 ">
                        <p class="text-muted mb-0 text-start">{viewFlight && viewFlight?.aircraft_model || 'N/A'}</p>
                      </div>
                    </div>
                  </div>

                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">End Date</p>
                      </div>
                      <div class="col-sm-9 ">
                        <p class="text-muted mb-0 text-start">{viewFlight && viewFlight?.arrived_date || 'N/A'}</p>
                      </div>
                    </div>
                  </div>


                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">End Time</p>
                      </div>
                      <div class="col-sm-9 ">
                        <p class="text-muted mb-0 text-start">{viewFlight && viewFlight?.arrived_time || 'N/A'}</p>
                      </div>
                    </div>
                  </div>



                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">Departure Date</p>
                      </div>
                      <div class="col-sm-9 ">
                        <p class="text-muted mb-0 text-start">{viewFlight && viewFlight?.departure_date || 'N/A'}</p>
                      </div>
                    </div>
                  </div>


                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">Departure Time</p>
                      </div>
                      <div class="col-sm-9 ">
                        <p class="text-muted mb-0 text-start">{viewFlight && viewFlight?.departure_time || 'N/A'}</p>
                      </div>
                    </div>
                  </div>


                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">Max Price</p>
                      </div>
                      <div class="col-sm-9 ">
                        <p class="text-muted mb-0 text-start">{viewFlight && viewFlight?.max_price || 'N/A'}</p>
                      </div>
                    </div>
                  </div>


                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">Seats</p>
                      </div>
                      <div class="col-sm-9 ">
                        <p class="text-muted mb-0 text-start">{
                          viewFlight && viewFlight?.FlightSeats.map((element) => (
                            // console.log('____________________________________________________element is here',element)
                            <label>{element?.seat ? element?.seat : 'N/A'}</label>
                          ))
                        }</p>
                      </div>
                    </div>
                  </div>

                  {viewFlight && viewFlight?.reason &&
                    <div class="card-body">
                      <div class="row border-bottom">
                        <div class="col-sm-3">
                          <p class="mb-0 text-start">Flight Deactived Reason</p>
                        </div>
                        <div class="col-sm-9 ">
                          <p class="text-muted mb-0 text-start">{viewFlight && viewFlight?.reason || 'N/A'}</p>
                        </div>
                      </div>
                    </div>
                  }


                  <div class="card-body">
                    <div class="row border-bottom">
                      <div class="col-sm-3">
                        <p class="mb-0 text-start">Days</p>
                      </div>
                      <div class="col-sm-9 ">
                        <p class="text-muted mb-0 text-start">{
                          viewFlight && viewFlight?.DayOperations.map((elem) => (
                            <div>{elem?.Day?.value ? elem?.Day?.value : 'N/A'}</div>
                          ))
                        }</p>
                      </div>


                    </div>
                  </div>

                </div>


              </div>

              <div>
                <h2 class="mb-0 text-start text-center py-5">Schedule for this Flight</h2>
              </div>
              <div class="view-flight-pagination">
                <BootstrapTable keyField='id' filter={filterFactory()} data={userData && userData?.data} noDataIndication={() => { return 'No Data Found' }} columns={columns} bordered={false} pagination={userData && paginationFactory(
                  {
                    sizePerPage: 10,
                    className: "view-flight-pagination",
                    page: 1,
                    lastPageText: '>>',
                    firstPageText: '<<',
                    showTotal: true,
                    //alwaysShowAllBtns:true,
                    //totalSize:100,
                    sizePerPageList: [
                      {
                        text: '10', value: 10
                      }, {
                        text: '20', value: 20
                      },
                      {
                        text: '30', value: 30
                      },
                      {
                        text: 'All', value: userData.length
                      }],
                    //nextPageText:'Next',
                    //prePageText:'Prev',
                    onPageChange: function (page, sizePerPage) {
                      console.log('page', page);
                      console.log('page', sizePerPage);
                    },
                    onSizePerPageChange: function (page, sizePerPage) {
                      console.log('page', page);
                      console.log('sizeperpage', sizePerPage)
                    }
                  }
                )} />
              </div>
            </div>
          </div>
        </main>
      </div>
      <div className=''>
									<Modal className='booked-wrapper'
										size="md"
										show={lgShow}
										onHide={() => setLgShow(false)}
										aria-labelledby="example-modal-sizes-title-sm"
										
									>
										<Modal.Header closeButton className='border-0 pb-0 '>
											{/* <Modal.Title id="example-modal-sizes-title-lg">
												Booked <label className='custom-book-red'></label>
											</Modal.Title> */}
										</Modal.Header>
										<Modal.Body className='pt-0'>
											<div id="example-modal-sizes-title-lg" className=' text-dark fs-5 fw-bold d-flex justify-content-center align-items-center mb-3'>
											Booked <label className='custom-book-red'></label>
											</div>
											<div>
												<div className='row'>
													<div className='col-lg-6'>
														<h3 className='fs-5 text-dark fw-bold mb-2'>
														Booked Date
														</h3>
													</div>
													<div className='col-lg-6 ps-0'>
													<p className='text-dark fw-medium mb-2'>{
															 <label>{flightDetail ? flightDetail?.departure_date+" "+flightDetail.departure_time : ''}</label>
													}</p>

													</div>

												</div>
											</div>
											<table className='w-100 border-dark border'>
												<thead>
												<tr>
													{/* <th>Booked Date</th> */}
													<th className='w-50 p-1 border-end border-dark'>Name</th>
													<th className='p-1'>Booked At</th>
												</tr>
												</thead>
												
												<tbody>
												{flightDetail && flightDetail?.FlightSeats.map((item) => (
													<tr>
														{/* <td>
															{flightDetail && item?.updatedAt ? moment(item?.updatedAt).format("DD-MM-YYYY h:mm:ss a") : 'N/A'}
														</td> */}
														<td className='w-50 p-1 border-end border-dark'>
															{flightDetail && item.User.name ? capitalizeWords(item.User.name) : 'N/A'}
														</td>
														<td className='p-1'>{flightDetail.max_price ? "₹ "+flightDetail.max_price : 'N/A'}</td>
													</tr>
												))
												}
												</tbody>
											</table>



										</Modal.Body>
									</Modal>
									</div>

{/* -------------------------------------------------second modal open for bid is here------------------------------------------------------ */}
<Modal className='booked-wrapper1'
										size="md"
										show={smShow1}
										onHide={() => setSmShow1(false)}
										aria-labelledby="example-modal-sizes-title-sm">
										<Modal.Header closeButton className='pb-0 border-0'>
											{/* <Modal.Title id="example-modal-sizes-title-md">
												Ongoing Bidding <label className='custom-bid-green'></label>
											</Modal.Title> */}
										</Modal.Header>
										<Modal.Body className='pt-0'>
											<div id="example-modal-sizes-title-md" className=' text-dark fs-5 fw-bold d-flex justify-content-center align-items-center mb-3'>
											Ongoing Bidding &nbsp;<label className='custom-bid-green'></label>
											</div>
											<div className='fw-bold'>
											Bid End Date & Time :  {
											bidDetail && bidDetail.map((elem,i) => (
												//console.log('________________________________________elem',elem)
												
												<>{
													i==0 && 
													elem?.Flight?.departure_date && moment(elem?.Flight?.departure_date).subtract(24,'hours').format("DD-MM-YYYY")+" "+elem?.Flight?.departure_time
													}</>
											))
											} 
											</div>
										<table className='w-100 border border-dark'>
										{/* <tr><th></th></tr> */}
												<thead>
												<tr>
													<th className='p-1 w-50 border-end border-dark'>Name</th>
													<th className='p-1'>Booked At</th>
												</tr>
												</thead>
												<tbody>
												{
													bidDetail && bidDetail.map((elem) => (
														<>
														
														<tr>
														<td className='p-1 w-50 border-end border-dark'>{elem?.User?.name ? capitalizeWords(elem?.User?.name) : 'N/A'}</td>
														<td className='p-1'>{elem?.bid_amount ? "₹"+elem?.bid_amount : 'N/A'}</td>
														</tr>
														</>
													))
												}
												</tbody>
										</table>
										</Modal.Body>
									</Modal>


{/* -----------------------------------------------------------------------------end of second bid here------------------------------------------------- */}

    </div>
  )
}
