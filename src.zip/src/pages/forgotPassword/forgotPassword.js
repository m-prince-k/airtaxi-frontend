import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { adminForgotPassword } from '../../component/store/forgotPassword/forgotSlice';
import ToasterContainer from '../../component/toastify/ToasterContainer'
import loginlogo from "../../util/img/icons/login-logo.png"

export default function ForgotPassword() {
    const dispatch=useDispatch();
    const navigate=useNavigate();
    const [values,setValues]=useState({email:""})
    const [Validations,setValidations]=useState({email:""});
    const {isSuccess,forgotDetail,message,isError}=useSelector((state) => state.forgotauth);

    useEffect(() => {
        if(isSuccess && forgotDetail) {
            setTimeout(() => {
                navigate("/")
            }, 5000);
            
        }
    },[isSuccess,forgotDetail])
   
    const handleChange = (e) => {
        const {name,value}=e.target;
        setValues({...values,[name]:value})
    }
    const validateAll = () => {
		let isValid=true;
		const Validations={};
		if(!values.email) {
			Validations.email='Please enter the email'
			isValid=false
		}
		if(values.email && !/\S+@\S+\.\S+/.test(values.email)) {
			Validations.email='Please enter the valid email address'
			isValid=false
		}
        if(!isValid){
            setValidations(Validations)
        }
        return isValid;
    }
    const handleSubmit = (e) => {
        e.preventDefault();
        const isValid=validateAll();
        if(!isValid){return false}
        const forgotPayload={email:values.email}
        dispatch(adminForgotPassword(forgotPayload))
    }

    const validateOne = (e) => {
		const { name } = e.target
		const value = values[name]
		let message = ''
	   
		if (!value) {
		  message = `please enter the email address`
		}
		// if (value && name === 'name' && (value.length < 3 || value.length > 50)) {
		//   message = 'Name must contain between 3 and 50 characters'
		// }
		console.log({...Validations},name,'________________________________________value is here =====================>>>>>>>>>>>>>>>>>>>',value)
		if (value && name === 'email' && !/\S+@\S+\.\S+/.test(value)) {
		  message = 'Email format must be as example@mail.com'
		}
		setValidations({...Validations, [name]: message })
	  }

  return (
    <div>
    <ToasterContainer/>
      <main className="d-flex w-100 login-screen">
    <div className="container d-flex flex-column">
        <div className="row vh-100">
            <div className="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
                <div className="d-table-cell align-middle">

                    <div className="text-center mt-4">                        
                    </div>
                    <div className="card">
                        <div className="card-body">
                            <div className="">
                                <div className="text-center">
										<img src={loginlogo} alt="Charles Hall" className="img-fluid login-logo" />
                                        <h1 className="h1 mt-2 mb-0">Forgot Password</h1>
                                        <h6 className='fw-light light-text my-1 mb-4'>Please enter your email here</h6>
									</div>
                                    <div className='row'>
										<div className='col-lg-8 mx-auto'>
                                                <form onSubmit={(e) => handleSubmit(e)} className='login-form'>
                                                    <div className="mb-3">
                                                    
                                                        {/* <label className="form-label">Email</label> */}
                                                    
                                                        <input className="form-control form-control-lg" onBlur={validateOne} value={values.email} onChange={handleChange} type="text" name="email" placeholder="Enter your email" />
                                                    <h6 style={{color:'red'}}>{Validations.email}</h6>
                                                    </div>
                                                    <div className="text-center mt-3">
                                                        <button type="submit" className="btn btn-lg btn-primary btn-yellow d-flex w-100 justify-content-center py-2">Submit</button> 
                                                    </div>
                                                </form>
                                        </div>
                                    </div>            
                                <a href="/airtaxi" className='d-flex justify-content-center mt-3 text-dark' >Back</a>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</main>

<script src="js/app.js"></script>
</div>
  )
}
