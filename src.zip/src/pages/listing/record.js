import React, { useEffect, useState } from 'react'
import useFetch from '../../customhook/useFetch';
import Loading from '../../component/loading';

export default function Record() {
  const [apiResult,ApiMethod] = useFetch();
  const [_loading,setLoading]=useState(false)
  useEffect(() => {
    setLoading(true)
    const output = ApiMethod({url:"https://jsonplaceholder.typicode.com/pos",method:"get"})
    if(!output){
      return <Loading></Loading>
    }
  },[])
  useEffect(() => {
    console.log('______________________+=========================>>>>>',apiResult)
  },[apiResult])

  return (
    <div>
        <table className="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    {
    apiResult.length===null
    ? (<Loading />)
    :
    (apiResult && apiResult?.map((val) => 
    <tr>
      <th scope="row">{val?.userId}</th>
      <td>{val?.title}</td>
      <td>
        {val?.body || 'N/A'}
      </td>
      <td><a href="#" >More</a></td>
    </tr>)
    )
}
  </tbody>
</table>
    </div>
  )
}
