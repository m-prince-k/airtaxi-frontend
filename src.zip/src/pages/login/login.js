import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { loginPost } from '../../component/store/login/authSlice';
import Avater from "../../util/img/avatars/avatar.jpg"
import ToasterContainer from '../../component/toastify/ToasterContainer';
import { toast } from 'react-toastify';
import loginlogo from "../../util/img/icons/login-logo.png"
import eyeslash from "../../util/img/icons/eye-slash.png"

export default function Login() {
	const navigate=useNavigate();
	const dispatch=useDispatch();
	const [passwordShown, setPasswordShown] = useState(false);
	const {isSuccess,isError,isLoading,loginDetail,error,message}=useSelector((state) => state.auth)

	const togglePasswordVisiblity = (e) => {
		e.preventDefault();
		setPasswordShown(passwordShown ? false : true);
	  };

	const [values,setValue]=useState({email:"",password:""});
	const [Validations,setValidations]=useState({email:"",password:""});


	useEffect(() => {
		if(isSuccess===true && loginDetail) {
			navigate('/dashboard')
		} else if(message && message.message) {
			toast.error(message.message)
		}
	},[isSuccess,message,loginDetail]);

	const validateAll = () => {
		let isValid=true;
		const Validations={};
		if(!values.email) {
			Validations.email='Please enter the email'
			isValid=false
		}
		if(values.email && !/\S+@\S+\.\S+/.test(values.email)) {
			Validations.email='Please enter the valid email address'
			isValid=false
		}
		if(!values.password) {
			Validations.password='Please enter the password'
			isValid=false
		} else if(values.password.length < 5 || values.password.length > 18) {
			Validations.password='Please Shuold be greater then 5 and less then 18'
			isValid=false 
		}
		if(!isValid) {
			setValidations(Validations)
		}
		return isValid;
	}
	const handleChange = (e) => {
		const {name,value}=e.target;
		setValue({...values,[name]:value})
	}
	
		const handleSubmit =  (event) => {
			event.preventDefault();
			const isValid=validateAll();
			if(!isValid) {return false;}
			
			const userPayload = {
				email:values.email,
				password:values.password
			}
			 dispatch(loginPost(userPayload))
			 
			 caches.keys().then((names) => {
				// Delete all the cache files
				names.forEach(name => {
					caches.delete(name);
				})
			});
		}
	

	const validateOne = (e) => {
		const { name } = e.target
		const value = values[name]
		let message = ''
	   
		if (!value) {
		  message = `${name} is required`
		}
		// if (value && name === 'name' && (value.length < 3 || value.length > 50)) {
		//   message = 'Name must contain between 3 and 50 characters'
		// }
		console.log({...Validations},name,'________________________________________value is here =====================>>>>>>>>>>>>>>>>>>>',value)
		if (value && name === 'email' && !/\S+@\S+\.\S+/.test(value)) {
		  message = 'Email format must be as example@mail.com'
		}
		setValidations({...Validations, [name]: message })
	  }

  return (
    <div>
		<ToasterContainer/>
      	<main className="d-flex w-100 login-screen">
		<div className="container d-flex flex-column">
			<div className="row vh-100">
				<div className="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
					<div className="d-table-cell align-middle">

						<div className="card">
							<div className="card-body pb-5">
								<div className="">
									<div className="text-center">
										<img src={loginlogo} alt="Charles Hall" className="img-fluid login-logo" />
										<h1 className="h1 mt-2 mb-0">AirTaxi Login</h1>
									</div>
									<div className='row'>
										<div className='col-lg-8 mx-auto'>
									<form onSubmit={(event) => handleSubmit(event)} className="mx-auto mt-4 login-form">
										<div className="mb-3">
											{/* <label className="form-label">Email</label> */}
											<input className="form-control" value={values.email} onBlur={validateOne} onChange={handleChange} type="text" name="email" placeholder="Enter your email" />
										<h6 style={{color:'red'}}>{Validations.email}</h6>
										</div>
												<div className="mb-3">
													{/* <label className="form-label">Password</label> */}
													<div className='position-relative'>
													<input className="form-control form-control-lg"  value={values.password} onBlur={validateOne} type={passwordShown ? "text" : "password"} onChange={handleChange} name="password" placeholder="Enter your password"/>
												
														<img src={eyeslash} alt="Charles Hall" onClick={(e) => togglePasswordVisiblity(e)} className="img-fluid position-absolute eye-slash" />
													
													</div>
													<h6 style={{color:'red'}}>{Validations.password}</h6>
													<div className='d-flex justify-content-between align-items-center mt-2'>
														<div>
															<label className="form-check">
														<input className="form-check-input" type="checkbox" value="remember-me" name="remember-me" />
															<span className="form-check-label">
															Remember me next time
															</span>
															</label>
														</div>
													<small>
														<a href="/airtaxi/forgotPassword">Forgot password?</a>
													</small>
												</div>		
											</div>
										<div className="text-center mt-4">
											<button type="submit" className="btn btn-lg btn-primary btn-yellow d-flex w-100 justify-content-center py-2">Login</button> 
										</div>
									</form>
									</div>
								</div>	
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</main>

	<script src="js/app.js"></script>
    </div>
  )
}
