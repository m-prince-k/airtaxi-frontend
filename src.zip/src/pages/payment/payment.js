import React from 'react'

export default function Payment() {
  return (
    <div>payment</div>
  )
}
