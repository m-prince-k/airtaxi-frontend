import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import SideBar from '../../component/sidebar/sidebar'
import { changePasswordUser, otpSentToChange, verifyOtpCPassword } from '../../component/store/user/userSlice'
import ToasterContainer from '../../component/toastify/ToasterContainer'
import Topbar from '../../component/topbar/topbar'
import eyeslash from "../../util/img/icons/eye-slash.png"
import 'bootstrap/dist/css/bootstrap.min.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import { toast } from 'react-toastify'

export default function ChangePassword() {
    const [passwordShown, setPasswordShown] = useState(false);
    const [passwordShown1, setPasswordShown1] = useState(false);
    const [passwordShown2, setPasswordShown2] = useState(false);
    const [resetHook,setResetHook]=useState(true)
    const [beforeHide,setBeforeHide]=useState(false);
    const [disabledBtn,setDisabledBtn]=useState(false)
    const [disabledBtn1,setDisabledBtn1]=useState(false)

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const { isSuccess, changePasswordDetail, otpSendDetail, message, OtpVerifyDetail } = useSelector((state) => state.user)
    const navigate = useNavigate()

console.log('=================================>>>>>',message)


    const handleChangePassword = (event) => {
        event.preventDefault();
        setDisabledBtn1(true)
        const isValid = validateAll();
        if (!isValid) { return false; }

        const userPayload = {
            new_password: values.new_password,
        }
        dispatch(changePasswordUser(userPayload))
    }

    useEffect(() => {
        if(isSuccess && message=="OTP has been verified successfully") {
            setBeforeHide(true);
           setShow(false)
           setResetHook(false);
        }   
    },[isSuccess,message])
    useEffect(() => {
        if (isSuccess === true && message=="otp has been sent successfully") {
                setShow(true)
        } else if(message.status==400 && message.message=="Old Password is not matched, Try again"){
            toast.error(message.message)
        } else if(isSuccess && message=="Password has been Changes successfully"){
            setTimeout(() => {navigate("/")}, 3000);
        }
    }, [isSuccess, message])

    const [values, setValue] = useState({ old_password: "", new_password: "", confirm_password: "",otp:"" });
    const [Validations, setValidations] = useState({ old_password: "", new_password: "", confirm_password: "" ,otp:"" });
    const dispatch = useDispatch();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setValue({ ...values, [name]: value })
    }

    const togglePasswordVisiblity = (e) => {
        e.preventDefault();
        setPasswordShown(passwordShown ? false : true);
    };

    const togglePasswordVisiblity1 = (e) => {
        e.preventDefault();
        setPasswordShown1(passwordShown1 ? false : true);
    };

    const togglePasswordVisiblity2 = (e) => {
        e.preventDefault();
        setPasswordShown2(passwordShown2 ? false : true);
    };

    const validateOne = (e) => {
        const { name } = e.target
        const value = values[name]
        let message = ''

        if(!value && name==="otp") {
            message=`Please enter the otp`
        }
        if (!value && name === 'old_password') {
            message = `Please enter the old password`
        }
        if (!value && name === 'new_password') {
            message = `Please enter the new password`
        }
        if (!value && name === 'confirm_password') {
            message = `Please enter the confirm password`
        }
        if (value && name === 'new_password' !== name === 'confirm_password') {
            message = `Password should be same as new password`
        }
        // if(!value && name === 'old' && !/\S+@\S+\.\S+/.test(value)) {
        //   message = 'Email format must be as example@mail.com'
        // }
        setValidations({ ...Validations, [name]: message })
    }

    const verifyOTPChangePassword = (event) => {
        event.preventDefault();
        setDisabledBtn(true)
        let payload={otp:values.otp}
        dispatch(verifyOtpCPassword(payload))
    }

    const validateOld = () => {
        let isValid = true;
        const Validations = {};
        if (!values.old_password) {
            Validations.old_password = "Please enter the old password"
            isValid = false
        }
        if (!isValid) {
            setValidations(Validations)
        }
        return isValid;
    }

    const validateAll = () => {
        let isValid = true;
        const Validations = {};
        if (!values.new_password) {
            Validations.new_password = "Please enter the new password"
            isValid = false
        }
        if (!values.confirm_password) {
            Validations.confirm_password = "Please enter the confirm password"
            isValid = false
        }
        if (values.new_password !== values.confirm_password) {
            Validations.confirm_password = "Password should be same as new password"
            isValid = false
        }

        if (!isValid) {
            setValidations(Validations)
        }
        return isValid;
    }

    const sendOtpHandleChange = (event) => {
        event.preventDefault();
        //consume here
   
        const isValid = validateOld();
        if (!isValid) { return false; }

        let payload = {
            old_password:values.old_password
        }
        dispatch(otpSentToChange(payload));

        caches.keys().then((names) => {
            // Delete all the cache files
            names.forEach(name => {
                caches.delete(name);
            })
        });
    }
    return (
        <div>
            <ToasterContainer />
            <div className='wrapper'>
                <SideBar />
                <div className="main">
                    <Topbar />
                    <main className="d-flex w-100">
                        <div className="container d-flex flex-column">
                            <div className="row">
                                <div className="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
                                    <div className="d-table-cell align-middle">

                                        <div className="text-center mt-4">
                                            <h1 className="h2">
                                                {
                                                    resetHook && <>Send OTP</>
                                                }
                                                { beforeHide && <>Change Password</>}
                                                
                                                </h1>

                                        </div>
                                        <div className="card">
                                            <div className="card-body">
                                                <div className="m-sm-4">
                                                 
                                                    { 
                                                    resetHook &&
                                                    <>
                                                        <form onSubmit={(event) => sendOtpHandleChange(event)}>
                                                        <div className="mb-3 position-relative">
                                                            <label className="form-label">Old Password*</label>
                                                            <input className="form-control form-control-lg" type={passwordShown ? "text" : "password"} maxLength={20} onBlur={validateOne} onChange={handleChange} name="old_password" value={values.first_name} placeholder="Enter your old password" />
                                                            <h6 style={{ color: 'red' }}>{Validations.old_password}</h6>
                                                            <img src={eyeslash} alt="Charles Hall" onClick={(e) => togglePasswordVisiblity(e)} className="img-fluid position-absolute old-eye-slash" />
                                                        </div>

                                                        <div className="text-center mt-3">
                                                            <button type="submit" disabled={disabledBtn} className="btn btn-lg btn-primary mx-2">Send Otp</button>
                                                        </div>
                                                    </form>
                                                    </>    
                                                    }
                                                       
                                                    
                                                    {
                                                        beforeHide && 
                                                    
                                                        <>
                                                        <form onSubmit={(event) => handleChangePassword(event)}>
                                                        <div className="mb-3 position-relative">
                                                            <label className="form-label">New Password*</label>
                                                            <input className="form-control form-control-lg" type={passwordShown1 ? "text" : "password"} maxLength={20} onBlur={validateOne} onChange={handleChange} name="new_password" value={values.last_name} placeholder="Enter your new password" />
                                                            <img src={eyeslash} alt="Charles Hall" onClick={(e) => togglePasswordVisiblity1(e)} className="img-fluid position-absolute new-eye-slash" />
                                                        </div>
                                                        <h6 style={{ color: 'red' }}>{Validations.new_password}</h6>


                                                        <div className="mb-3 position-relative">
                                                            <label className="form-label">Confirm Password*</label>
                                                            <input className="form-control form-control-lg" type={passwordShown2 ? "text" : "password"} maxLength={20} onBlur={validateOne} onChange={handleChange} name="confirm_password" value={values.last_name} placeholder="Enter your confirm password" />
                                                            <img src={eyeslash} alt="Charles Hall" onClick={(e) => togglePasswordVisiblity2(e)} className="img-fluid position-absolute confirm-eye-slash" />
                                                        </div>
                                                        <h6 style={{ color: 'red' }}>{Validations.confirm_password}</h6>
                                                        <div className="text-center mt-3">
                                                            <button type="submit" disabled={disabledBtn1} className="btn btn-lg btn-primary mx-2">Update Password</button>
                                                        </div>
                                                    </form>
                                                        </>
                                                    }
                                                        


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>OTP Confirmation</Modal.Title>
                </Modal.Header>
                <Modal.Body>Please verify the otp ?</Modal.Body>
                <Form onSubmit={(event) => verifyOTPChangePassword(event)} className="p-3 pt-0">
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>OTP (One Time Password)</Form.Label>
                        <Form.Control type="text" onBlur={validateOne} name="otp" maxLength={10} onChange={handleChange} value={values.otp} placeholder="Enter the otp" />
                        <h6 style={{ color: 'red' }}>{Validations.otp}</h6>
                    </Form.Group>


                    <Button variant="primary" type="submit">
                        Verify
                    </Button>
                </Form>
            </Modal>
        </div>
    )
}
