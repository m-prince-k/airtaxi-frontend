import React,{useState,useEffect, forwardRef, useDebugValue, useRef} from 'react'
import SideBar from '../../component/sidebar/sidebar'
import dummy from "../../util/img/photos/dummy.png"

import Topbar from '../../component/topbar/topbar';
import Footer from '../../component/footer';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { Navigate, useNavigate } from 'react-router-dom';
import ToasterContainer from '../../component/toastify/ToasterContainer';
import { updateAuthProfile } from '../../component/store/user/userSlice';
import { BASE_IMG_URL } from '../../util/constant';
import { Box, CircularProgress } from '@material-ui/core';

export default function EditProfile() {

  const [values,setValue]=useState({first_name:"",last_name:"",email:"",profile_pic:"",location:"",country_code:"",phone_number:""});
	const [Validations,setValidations]=useState({email:"",last_name:"",first_name:"",location:"",country_code:"",phone_number:""});
    const [imageName,setImageName]=useState("")
	const [profile, setProfileDetail] = useState("")
	const navigate=useNavigate();
	const [loader, setLoader] = useState(false);
const {editProfileDetail,isSuccess,profileDetail,isProfileUpdated,message:resMessage}	=useSelector((state) => state.user)

const previousProps = useRef({ isProfileUpdated }).current;

useEffect(() => {
    if (profileDetail) {
      setProfileDetail(profileDetail)
    }
  }, [profileDetail]);

useEffect(() => {
		profile && setValue({first_name:profile?.first_name,last_name:profile?.last_name,email:profile?.email,location:profile?.location,country_code:profile?.country_code,phone_number:profile?.phone_number})
	}, [profile])

	useEffect(() => {
		if (previousProps?.isProfileUpdated !== isProfileUpdated) {
			if (isProfileUpdated) {
				setLoader(true)
				setTimeout(() => {
					navigate("/")
				}, 4000);
				
			} else if (!isProfileUpdated && resMessage) {
				toast.error("something went wrong")
			}		
		}
		return () => {
			previousProps.isProfileUpdated = isProfileUpdated;
		  };
	},[resMessage,isProfileUpdated]);

  const [image,setImage]=useState("")
	const dispatch=useDispatch();

  const validateAll = () => {
		let isValid=true;
		const Validations={};
		if(!values.first_name) {
			Validations.first_name="Please enter the first name"
			isValid=false
		}
		if(!values.last_name) {
			Validations.last_name="Please enter the last name"
			isValid=false
		}
		if(!values.country_code) {
			Validations.country_code="Please enter the country code"
			isValid=false
		}
		if(!values.phone_number) {
			Validations.phone_number="Please enter the Phone Number"
			isValid=false
		}
		
		if(!values.location) {
			Validations.location="Please enter the location"
			isValid=false
		}
		if(!values.email) {
			Validations.email='Please enter the email'
			isValid=false
		}
		if(!values.first_name.match(/^[a-zA-Z]*$/)) {
			Validations.first_name='Please enter the valid first name'
			isValid=false
		}
		if(!values.last_name.match(/^[a-zA-Z]*$/)) {
			Validations.last_name='Please enter the valid last name'
			isValid=false
		}
		if(values.country_code) {
			var regex = /^(\+?\d{1,3}|\d{1,4})$/
			var match = values.country_code.match(regex);
			if(!match){
				Validations.country_code = 'Please enter the valid country code'
			}
		}
		if(!values.phone_number.match(/^\d*[.]?\d*$/)){
			Validations.phone_number='Please enter the valid phone number'
			isValid=false
		}
		if(values.phone_number.length < 10){
			Validations.phone_number='Please enter correct number of digits'
			isValid=false
		}
		if(values.phone_number.length < 10){
			Validations.phone_number='Please enter correct number of digits'
			isValid=false
		}
		if(!isValid) {
			setValidations(Validations)
		}
		return isValid;
	}
  const handleImageChange=(e)=>{
    e.preventDefault();
	setImageName(e.target.files[0].name)
    if(e.target.files[0].length!==0){
      setImage(URL.createObjectURL(e.target.files[0]))
    }
  }
  const handleChange = (e) => {
		const {name,value}=e.target;
		setValue({...values,[name]:value})
	}
	const handleSubmit = (event) => {
		event.preventDefault();
		const isValid=validateAll();
		if(!isValid) {return false;}
		
		const userPayload = {
      		first_name:values.first_name,
			email:values.email,
			last_name:values.last_name,
			name:values.first_name + " " + values.last_name,
			location:values.location,
			country_code:values.country_code,
			phone_number:values.phone_number,
			profile_pic:imageName
		}
		console.log(userPayload)
		dispatch(updateAuthProfile(userPayload))

		caches.keys().then((names) => {
            // Delete all the cache files
            names.forEach(name => {
                caches.delete(name);
            })
        });
	}


	const validateOne = (e) => {
		const { name } = e.target
		const value = values[name]
		let message = ''

		if(!value && name === 'first_name') {
			message=`Please enter the first name`
		}	
	    if (!value && name==='last_name') {
		  message = `Please enter the last name`
	    }
		if(!value && name==='email') {
			message=`Please enter the email`
		}
		
		if(!value && name==='country_code') {
			message=`Please enter the country code`
		}
		if(!value && name==='phone_number') {
			message=`Please enter the phone number`
		}
		if(values.country_code) {
			var regex = /^(\+?\d{1,3}|\d{1,4})$/
			var match = values.country_code.match(regex);
			if(!match){
				Validations.country_code = 'Please enter the valid country code'
			}
		}
		  if(value && name==='phone_number' && !/^\d*[.]?\d*$/.test(value)) {
			message=`Please enter the valid phone number`
		}
		if(!value && name === 'location') {
			message=`Location must be added`
		}
		
		
		if(value && name === 'email' && !/\S+@\S+\.\S+/.test(value)) {
		  message = 'Email format must be as example@mail.com'
		}
		setValidations({...Validations, [name]: message })
	  }

  return (
    <div>
		<ToasterContainer/>
      <div className='wrapper'>
        <SideBar/>
        <div className="main">
        <Topbar/>
      <main className="d-flex w-100">
		<div className="container d-flex flex-column">
			<div className="row">
				<div className="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
					<div className="d-table-cell align-middle">

						<div className="text-center mt-4">
							<h1 className="h2">Update Profile</h1>
							
							{/* <p className="lead">
								Start creating the best possible user experience for you customers.
							</p> */}
						</div>
						
						<div className="card">
							<div className="card-body">
								<div className="m-sm-4">
									<form onSubmit={(event) => handleSubmit(event)}>
										<div className="mb-3">
											<label className="form-label">First Name*</label>
											<input className="form-control form-control-lg" type="text" maxLength={20} onBlur={validateOne} onChange={handleChange} name="first_name" value={values.first_name} placeholder="Enter your first name" />
                   
                    </div>
					<h6 style={{color:'red'}}>{Validations.first_name}</h6>
					<div className="mb-3">
											<label className="form-label">Last Name*</label>
											<input className="form-control form-control-lg" type="text" maxLength={20} onBlur={validateOne}   onChange={handleChange} name="last_name" value={values.last_name} placeholder="Enter your last name" />
                   
                    </div>
					<h6 style={{color:'red'}}>{Validations.last_name}</h6>
										<div className="mb-3">
											<label className="form-label">Email*</label>
											<input className="form-control form-control-lg" type="email" onBlur={validateOne} maxLength={20}  name="email" onChange={handleChange} value={values.email} placeholder="Enter your email" />
                      <h6 style={{color:'red'}}>{Validations.email}</h6>
                    </div>
										
					<div className="mb-3">
											<label className="form-label">Country Code*</label>
											<input className="form-control form-control-lg" type="text" maxLength={5}  onBlur={validateOne}  name="country_code" value={values.country_code} onChange={handleChange} placeholder="Enter your Country Code" />
                      <h6 style={{color:'red'}}>{Validations.country_code}</h6>
                    </div>
					{
															loader && 
															<div style={{ marginLeft: "180px" }}>
																<Box sx={{ display: 'flex' }}><CircularProgress /></Box>
															</div>
														}
					<div className="mb-3">
											<label className="form-label">Phone Number*</label>
											<input className="form-control form-control-lg" type="text" maxLength={20} onBlur={validateOne}  name="phone_number" value={values.phone_number} onChange={handleChange} placeholder="Enter your Phone number" />
                      <h6 style={{color:'red'}}>{Validations.phone_number}</h6>
					  
                    </div>

							{
								profile && profile.user_role==1 &&
								<div className="mb-3 profile-pic-wrap">
								<label className="form-label">Profile pic</label><br/>
								<img src={image ? image : profile?.profile_pic ? BASE_IMG_URL+profile?.profile_pic.toLowerCase()  : dummy} alt="user_profile_pic" height={100} width={100} /><a href="#"  class="cross-img" onClick={() => setImage(null)}>X</a>
								<input className="form-control form-control-lg" type="file" onChange={handleImageChange} name="profile_pic"/>
							</div>
							}

										<div className="mb-3">
											<label className="form-label">Location*</label>
											<input className="form-control form-control-lg" type="text" maxLength={50} name="location" onBlur={validateOne}  onChange={handleChange} value={values.location} placeholder="Enter your location" />
                    </div>
					<h6 style={{color:'red'}}>{Validations.location}</h6>
										<div className="text-center mt-3">
										<button type="submit" className="btn btn-lg btn-primary mx-2">Update Profile</button>
										</div>
									</form>
									
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
              
  </main>
  <Footer/>
  </div>
    </div>
    </div>
  )
}
