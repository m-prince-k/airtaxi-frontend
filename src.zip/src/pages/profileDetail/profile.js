import React, { useState, useEffect } from 'react'
import SideBar from '../../component/sidebar/sidebar'
import Topbar from '../../component/topbar/topbar';
import { getAuthProfile } from '../../component/store/user/userSlice';
import { useDispatch, useSelector } from 'react-redux';
import { BASE_IMG_URL } from '../../util/constant';
import dummy from "../../util/img/photos/dummy.png"
import { Link } from 'react-router-dom';

export default function Profile() {
  const dispatch = useDispatch();
  const [profile, setProfileDetail] = useState("")
  const { profileDetail } = useSelector((state) => state.user);

  useEffect(() => {
    dispatch(getAuthProfile())
  }, []);

  useEffect(() => {
    if (profileDetail) {
      setProfileDetail(profileDetail)
    }
  }, [profileDetail]);

  return (
    <div className='wrapper'>
      <SideBar />
      <div className="main">
        <Topbar />
        <main className="d-flex w-100 employee-wrapper profile-detail">
          <div className="container d-flex flex-column">
            <div className="row justify-content-center mt-5">
              <div className='col-md-9 px-0'>
                <div className='profile-info p-4'>
                  <div className=''>
                    <h3 className=' fs-2'>Profile Information</h3>
                  </div>
                  <div class="card-body">
                    <div className='d-flex justify-content-between'>
                      <h3 className='text-start'>Profile Detail</h3>
                      <Link to="/editProfile">
                        <span className='custom-svgicons'>
                          <span className='svgIcon'>
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M3.27825 14.4C3.32325 14.4 3.36825 14.3955 3.41325 14.3887L7.19775 13.725C7.24275 13.716 7.2855 13.6957 7.317 13.662L16.8547 4.12425C16.8756 4.10343 16.8922 4.07871 16.9034 4.05149C16.9147 4.02427 16.9205 3.99509 16.9205 3.96562C16.9205 3.93616 16.9147 3.90698 16.9034 3.87976C16.8922 3.85254 16.8756 3.82782 16.8547 3.807L13.1153 0.06525C13.0725 0.0225 13.0162 0 12.9555 0C12.8947 0 12.8385 0.0225 12.7958 0.06525L3.258 9.603C3.22425 9.63675 3.204 9.67725 3.195 9.72225L2.53125 13.5067C2.50936 13.6273 2.51718 13.7513 2.55404 13.8682C2.59089 13.985 2.65566 14.0911 2.74275 14.1772C2.89125 14.3212 3.078 14.4 3.27825 14.4ZM4.79475 10.476L12.9555 2.3175L14.6047 3.96675L6.444 12.1253L4.44375 12.4785L4.79475 10.476ZM17.28 16.29H0.72C0.32175 16.29 0 16.6117 0 17.01V17.82C0 17.919 0.081 18 0.18 18H17.82C17.919 18 18 17.919 18 17.82V17.01C18 16.6117 17.6783 16.29 17.28 16.29Z" fill="#808385" />
                            </svg>
                          </span>
                          <span className='hover-text'>
                            <span className='hover-innertext'>
                              <span className='inner-text'>
                                Edit
                              </span>
                            </span>
                          </span>
                        </span>
                      </Link>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Role</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start cutom-upper-letter">
                          {
                            profile.user_role==='1' ? (<h6>Admin</h6>)
                            : profile.user_role==='2' ? (<h6>Normal User</h6>)
                            : profile.user_role==='3' ? (<h6>Employee</h6>)
                            :'Role not found'
                          }</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">First Name</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start cutom-upper-letter">{profile && profile.first_name || 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start cutom-upper-letter">Last Name</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile && profile.last_name || 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Email</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile && profile.email || 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Country Code</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile && profile.country_code || 'N/A'}</p>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Mobile</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile && profile.phone_number || 'N/A'}</p>
                      </div>
                    </div>
                  {
                    profile.user_role == 1  && 

                  
                    <div class="row border-bottom">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">Profile Pic</p>
                      </div>
                      <div class="col-sm-3 py-3 text-center">
                        <img src={profile.profile_pic ? BASE_IMG_URL + profile.profile_pic.toLowerCase() : dummy} alt="user_profile_pic" height={100} width={100} />
                      </div>
                    </div>
                  }
                    <div class="row">
                      <div class="col-sm-3 py-3">
                        <p class="mb-0 text-start">location</p>
                      </div>
                      <div class="col-sm-9 py-3">
                        <p class="text-muted mb-0 text-start">{profile && profile.location || 'N/A'}</p>
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

  )
}
