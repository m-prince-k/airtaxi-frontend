import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { loginPost } from '../../component/store/login/authSlice';
import Avater from "../../util/img/avatars/avatar.jpg"
import ToasterContainer from '../../component/toastify/ToasterContainer';
import { toast } from 'react-toastify';
import { reset, resetPassword } from '../../component/store/forgotPassword/forgotSlice';
import logo from "../../util/img/icons/logo.png"
import eyeslash from "../../util/img/icons/eye-slash.png"

export default function ResetPassword({match}) {
	const paramData=useParams()
	const navigate=useNavigate();
	const dispatch=useDispatch();
	const [passwordShown, setPasswordShown] = useState(false);
    const [passwordShown1, setPasswordShown1] = useState(false);
	const {resetDetail,message,isError,isSuccess,reset}=useSelector((state) => state.forgotauth)

	const [values,setValue]=useState({new_password:"",confirm_password:""});
	const [Validations,setValidations]=useState({new_password:"",confirm_password:""});


	const togglePasswordVisiblity = (e) => {
		e.preventDefault();
		setPasswordShown(passwordShown ? false : true);
	  };

      const togglePasswordVisiblity1 = (e) => {
		e.preventDefault();
		setPasswordShown1(passwordShown1 ? false : true);
	  };

	useEffect(() => {
		if(isSuccess===true){
			setTimeout(() => {
				navigate('/')
				dispatch(reset())
			},3000)
		}
	},[isSuccess])

	const validateAll = () => {
		let isValid=true;
		const Validations={};
		if(!values.new_password) {
			Validations.new_password='Please enter the new Password'
			isValid=false
		}else if(!values.new_password.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/)){
			Validations.new_password='Please enter the valid new password at least 8 character with upper letter ,special character,number'
			isValid=false
		} 
		if(!values.confirm_password.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/)){
			Validations.confirm_password='Please enter the valid new password at least 8 character with upper letter ,special character,number'
			isValid=false
		}
		
        if(values.new_password!==values.confirm_password){
            Validations.confirm_password='New Password and Confirm Password should be matched'
			isValid=false
        }
		if(!values.confirm_password) {
			Validations.confirm_password='Please enter the confirm password'
			isValid=false
		} 
		if(!isValid) {
			setValidations(Validations)
		}
		return isValid;
	}

	const validateOne = (e) => {
		const { name } = e.target
		const value = values[name]
		let message = ''
	   
		if (!value && name==='new_password' ) {
		  message = `Please enter the new Password`
		} 		
		setValidations({...Validations, [name]: message })
	  }

	const handleChange = (e) => {
		const {name,value}=e.target;
		setValue({...values,[name]:value})
	}
	const handleSubmit = (event) => {
		event.preventDefault();
		const isValid=validateAll();
		if(!isValid) {return false;}

		const resetPayload = {
			new_password:values.new_password,
			confirm_password:values.confirm_password,
			token:paramData?.token
		}
		dispatch(resetPassword(resetPayload))
	}
  return (
    <div>
		<ToasterContainer/>
      	<main className="d-flex w-100">
		<div className="container d-flex flex-column">
			<div className="row vh-100">
				<div className="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
					<div className="d-table-cell align-middle">

						<div className="text-center mt-4">
							<h1 className="h2">Reset Password</h1>
						</div>
						<div className="card">
							<div className="card-body">
								<div className="m-sm-4">
									<div className="text-center">
										<img src={logo} alt="Charles Hall" className="img-fluid rounded-circle" width="132" height="132" />
									</div>
								
									<form onSubmit={handleSubmit}>
										<div className="mb-3 position-relative">
											<label className="form-label">New Password</label>
											<input className="form-control form-control-lg" onBlur={validateOne} value={values.new_password} onChange={handleChange} type={passwordShown ? "text" : "password"} name="new_password" placeholder="Enter the new password" />
											<img src={eyeslash} alt="Charles Hall" onClick={(e) => togglePasswordVisiblity(e)} className="img-fluid position-absolute new-eye-slash" />
										</div>
										<h6 style={{color:'red'}}>{Validations.new_password}</h6>
										<div className="mb-3 position-relative">
											<label className="form-label">Confirm Password</label>
											<input className="form-control form-control-lg" onBlur={validateOne} value={values.confirm_password} type={passwordShown1 ? "text" : "password"} onChange={handleChange} name="confirm_password" placeholder="Enter the confirm password" />
											<img src={eyeslash} alt="Charles Hall" onClick={(e) => togglePasswordVisiblity1(e)} className="img-fluid position-absolute new-eye-slash" />
										</div>
										<h6 style={{color:'red'}}>{Validations.confirm_password}</h6>
										
										<div className="text-center mt-3">
											<button type="submit" className="btn btn-lg btn-primary">Submit</button> 
										</div>
									</form>
									
								
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</main>

	<script src="js/app.js"></script>
    </div>
  )
}
