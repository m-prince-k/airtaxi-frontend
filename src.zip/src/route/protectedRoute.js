import React from "react";
import { useSelector } from "react-redux";
import { Navigate, Outlet } from "react-router-dom";




export const useAuth = () => {
    const userData=JSON.parse(localStorage.getItem("authLogger"));
    const user=userData ? {logger :true} : {logger:false};
    return user.logger;
}
export const ProtectedRouteCheck = ({children}) => {
    const isAuth=useAuth();
    return isAuth ? <Navigate to="/dashboard" /> : children; 
}

const ProtectedRoute = () => {
    const isAuth = useAuth();
    return isAuth ? <Outlet/> : <Navigate to="/" />;
};
export const ProtectedResetPassword = () => {
    // const {message}=useSelector((state) => state.forgotauth);
    // console.log('route message is here',message)
    // if(message) {
    //     return message.message = 'Token has been expired ,Please Try again' ? <Navigate to="/forgotPassword" /> : children
    // } 
}
export default ProtectedRoute;