import React from "react";
import { Route, Routes } from "react-router-dom";
import Login from "../pages/login/login";
import Dashboard from "../pages/dashboard/dashboard";
import Record from "../pages/listing/record";
import ProtectedRoute, { ProtectedRouteCheck, ProtectedResetPassword } from "./protectedRoute";
import Employee from "../pages/employee/employee";
import ForgotPassword from "../pages/forgotPassword/forgotPassword";
import ResetPassword from "../pages/resetPassword/resetPassword";
import CreateEmployee from "../pages/employee/createemployee";
import User from "../pages/user/user";
import CreateUser from "../pages/user/createuser";

import EditEmployee from "../pages/employee/editEmployee";
import Profile from "../pages/profileDetail/profile";
import EditUser from "../pages/user/editUser";
import ViewUser from "../pages/user/viewUser";
import ViewEmployee from "../pages/employee/viewEmployee";
import CreateFlight from "../pages/flight/createFlight";
import FlightListing from "../pages/flight/flightListing";
import Thanks from "../component/thanks/thanks";
import EditProfile from "../pages/profileDetail/editProfile";
import ChangePassword from "../pages/profileDetail/changePassword";

import EditFlight from "../pages/flight/editFlight";
import AddAirCraft from "../pages/aircraft/addAirCraft";
import AirCraftListing from "../pages/aircraft/aircraftListing";
import ViewAirCraft from "../pages/aircraft/viewAircraft";
import EditAirCraft from "../pages/aircraft/editAircraft";
import Airport from "../pages/airport/airport";
import ViewFlight from "../pages/flight/viewFlight";
import Payment from "../pages/payment/payment";

export default function RouterLink(props) {

    return (
        <>
            <Routes>
                <Route exact path="/" element={<ProtectedRouteCheck><Login /></ProtectedRouteCheck>} />
               
                <Route element={<ProtectedRoute />}>
                <Route exact path="/dashboard" element={<Dashboard />} />
                <Route path="/employee" element={<Employee />} />
                <Route path="/editEmployee/:id" element={<EditEmployee />} />
                <Route path="/editUser/:id" element={<EditUser />} />
                <Route path="/viewUser/:id" element={<ViewUser />} />
                <Route path="/viewEmployee/:id" element={<ViewEmployee />} />

                <Route path="/createEmployee" element={<CreateEmployee/>}/>
                <Route path="/user" element={<User/>}/>
                <Route path="/createUser" element={<CreateUser/>}/>
                <Route path="/flightListing" element={<FlightListing/>}/>
                <Route path="/profile" element={<Profile/>}/>
                <Route path="/editProfile" element={ <EditProfile/> } />
                <Route path="/createFlight" element={<CreateFlight />} />
                <Route path="/viewFlight/:id" element={<ViewFlight />} />
                <Route path="/editFlight/:id" element={<EditFlight/> } />

                <Route path="/addAirCraft" element={<AddAirCraft />} />
                <Route path="/aircraftListing" element={<AirCraftListing />} />
                <Route path="/viewAircraft/:id" element={<ViewAirCraft />} />
                <Route path="/editAirCraft/:id" element={<EditAirCraft />} />
                <Route path="/payment" element={<Payment />} />
                </Route>
                {/* <Route element={<ProtectedRoute />}>
                    <Route path="/listing" element={<Record />} />
                    <Route path="/dashboard" element={<Dashboard />} />
                    
                    
                </Route> */}
                <Route path="/airport" element={<Airport />} />
                <Route path="/forgotPassword" element={<ForgotPassword/>}/>
                <Route path="/changePassword" element={<ChangePassword/>}/>
                    
                    <Route path="/resetPassword/:token" element={<ResetPassword/> } />
                    <Route path="/thanks" element={<Thanks/>} />
                   
            </Routes>
            {/* <Route path="*" element={() => {
                        return ('Something went wrong')
                    }}/> */}
        </>
    )
}