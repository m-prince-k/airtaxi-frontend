//const developmentBaseUrl="http://localhost:4000/api/v1/admin/"
const developmentBaseUrl="https://stgn.appsndevs.com/airtaxiapi/api/v1/admin/"
//const StagingBaseUrl="https://stgn.appsndevs.com/airtaxi/api/v1/admin/"
const liveBaseUrl="http://airtaxi:5000/api/v1"
const BASE_IMG_URL="https://stgn.appsndevs.com/airtaxi/public/upload/"

const forgotPasswordBySuperAdmin="forgotPasswordBySuperAdmin"
const superAdminLogin="superAdminLogin"
const blockUnblockUser="blockUnblockUser"
const getEmployeeListing="getEmployeeListing"
const getUserListing= "getUserListing"
const addUser="addUser"
const resetPasswordBySuperAdmin="resetPasswordBySuperAdmin"
const getFilledEmployee="getFilledEmployee"
const editUserByAdmin="editEmployeeByAdmin"
const deleteEmp="deleteEmp"
const getUserProfile="getUserProfile"
const Count="Count"
const deleteUser="deleteUser"
const viewUser="viewUser"
const getFilledUser="getFilledUser"
const editUser="editUser"
const viewEmployeeProfile="viewEmployeeProfile"
const blockUnblockEmployee="blockUnblockEmployee"
const addemployee="addemployee"
const editProfile="editProfile"
const changePasswordForUser="changePasswordForUser"
const getFlight="getFlight"
const getAllAirport="getAllAirport"
const getAllAirCraft= "getAllAirCraft"
const getAllDays="getAllDays"
const createFlight="createFlight"
const blockFLightUnBlockFlight="blockFLightUnBlockFlight"
const deleteFLight="deleteFLight"
const createAircraft="createAircraft"
const editFlight="editFlight"
const autoPopulateFlightDetail="autoPopulateFlightDetail"
const blockUnBlockAirCraft="blockUnBlockAirCraft"
const autoPopulateAircraft="autoPopulateAircraft"
const updateAircraft="updateAircraft"
const deleteAircraft="deleteAircraft"
const viewAirCraft="viewAirCraft"
const otpSend="otpSend"
const verifyOtp="verifyOtp"
const getSingleForBookedSeat="getSingleForBookedSeat"
const viewFlight="viewFlight"
const scheduleFlightByParentId="scheduleFlightByParentId"
export {
    developmentBaseUrl,
    addemployee,
    liveBaseUrl,
    forgotPasswordBySuperAdmin,superAdminLogin,
    blockUnblockUser,
    getEmployeeListing,
    getUserListing,
    addUser,
    resetPasswordBySuperAdmin,
    getFilledEmployee,
    editUserByAdmin,
    deleteEmp,
    getUserProfile,
    Count,
    deleteUser,
    viewUser,
    getFilledUser,
    editUser,
    viewEmployeeProfile,
    blockUnblockEmployee,
    BASE_IMG_URL,
    editProfile,
    changePasswordForUser,
    getFlight,
    getAllAirport,
    getAllAirCraft,
    getAllDays,
    createFlight,
    blockFLightUnBlockFlight,
    deleteFLight,
    createAircraft,
    editFlight,
    autoPopulateFlightDetail,
    blockUnBlockAirCraft,
    autoPopulateAircraft,
    updateAircraft,
    deleteAircraft,
    viewAirCraft,
    otpSend,
    verifyOtp,
    getSingleForBookedSeat,
    viewFlight,
    scheduleFlightByParentId
}